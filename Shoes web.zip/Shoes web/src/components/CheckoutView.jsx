import React, { useState, useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import { SAMPLE_PINCODES } from '../data/products';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  Lock,
  ShieldCheck,
  CreditCard,
  Truck,
  ArrowRight,
  ArrowLeft,
  ShoppingBag,
  Sparkles,
  MapPin,
  Mail,
  User,
  Phone,
  Package,
  QrCode,
  AlertCircle,
  Copy,
  Check,
  Building,
  RefreshCw
} from 'lucide-react';

const INDIAN_STATES = [
  "Andhra Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", "Delhi NCR",
  "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand",
  "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Odisha", "Punjab",
  "Rajasthan", "Tamil Nadu", "Telangana", "Uttar Pradesh", "Uttarakhand", "West Bengal"
];

export const CheckoutView = () => {
  const {
    cart,
    cartSubtotalINR,
    discountAmountINR,
    discountedSubtotalINR,
    shippingAmountINR,
    gstInclusiveAmountINR,
    cartTotalINR,
    isCodEligible,
    codMaxLimit,
    formatPrice,
    clearCart,
    setCurrentView,
    discountCode,
    discountPercent,
    showToast,
    setIsOrderTrackerOpen,
    setTrackedOrder
  } = useShop();

  const [errors, setErrors] = useState({});
  const [isProcessing, setIsProcessing] = useState(false);

  const [step, setStep] = useState(1); // 1: Contact & Address, 2: Carrier, 3: Payment, 4: Confirmed
  const [shippingMethod, setShippingMethod] = useState('bluedart_air');
  const [paymentMethod, setPaymentMethod] = useState('upi'); // 'upi' | 'cod' | 'emi' | 'card' | 'netbanking'
  const [selectedUpiApp, setSelectedUpiApp] = useState('gpay'); // 'gpay' | 'phonepe' | 'paytm' | 'bhim' | 'qr'
  const [customUpiId, setCustomUpiId] = useState('');
  const [upiVerified, setUpiVerified] = useState(false);
  const [selectedEmiTenure, setSelectedEmiTenure] = useState(3);
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);

  // Form inputs for Indian Market
  const [formData, setFormData] = useState({
    fullName: 'Kabir Sharma',
    email: 'kabir.sharma@example.in',
    phone: '+91 98765 43210',
    flatHouse: 'Flat 402, Prestige Cyber Heights',
    streetAddress: '100 Feet Road, HAL 2nd Stage, Indiranagar',
    landmark: 'Near Indiranagar Metro Station',
    city: 'Bengaluru',
    state: 'Karnataka',
    pincode: '560038',
    country: 'India',
    isGuest: true,
    cardNumber: '•••• •••• •••• 4242',
    cardExpiry: '12/28',
    cardCvc: '888',
    cardName: 'KABIR SHARMA'
  });

  const [orderNumber, setOrderNumber] = useState('');

  // Handle pincode autofill and validation clearing
  const handlePincodeChange = (e) => {
    const pin = e.target.value.replace(/\D/g, '').slice(0, 6);
    setFormData((prev) => ({ ...prev, pincode: pin }));
    if (errors.pincode) {
      setErrors((prev) => {
        const updated = { ...prev };
        delete updated.pincode;
        return updated;
      });
    }
    if (pin.length === 6 && SAMPLE_PINCODES[pin]) {
      const matched = SAMPLE_PINCODES[pin];
      setFormData((prev) => ({
        ...prev,
        city: matched.city.split(',')[0],
        state: matched.state.includes('Delhi') ? 'Delhi NCR' : matched.state
      }));
      if (errors.city) {
        setErrors((prev) => {
          const updated = { ...prev };
          delete updated.city;
          return updated;
        });
      }
      showToast(`Detected location: ${matched.city}, ${matched.state}`, 'info');
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => {
        const updated = { ...prev };
        delete updated[name];
        return updated;
      });
    }
  };

  const validateAddressForm = () => {
    const errs = {};
    if (!formData.fullName || formData.fullName.trim().length < 2) {
      errs.fullName = 'Full name is required (min 2 characters)';
    }

    const cleanPhone = formData.phone.replace(/\D/g, '').slice(-10);
    if (!cleanPhone || cleanPhone.length !== 10 || !/^[6-9]\d{9}$/.test(cleanPhone)) {
      errs.phone = 'Valid 10-digit Indian mobile required (starts with 6-9)';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email || !emailRegex.test(formData.email.trim())) {
      errs.email = 'Valid email required for GST Tax Invoice';
    }

    const cleanPin = (formData.pincode || '').replace(/\D/g, '');
    if (cleanPin.length !== 6) {
      errs.pincode = 'Valid 6-digit Indian Pincode required';
    }

    if (!formData.city || formData.city.trim().length < 2) {
      errs.city = 'City / District is required';
    }

    if (!formData.flatHouse || formData.flatHouse.trim().length < 1) {
      errs.flatHouse = 'House, Flat, or Building name is required';
    }

    if (!formData.streetAddress || formData.streetAddress.trim().length < 3) {
      errs.streetAddress = 'Street / Colony address is required';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleVerifyUpi = () => {
    if (customUpiId.includes('@')) {
      setUpiVerified(true);
      showToast('UPI ID Verified successfully! Linked to Verified Banking Account.', 'success');
    } else {
      showToast('Please enter a valid UPI ID (e.g. username@okhdfcbank)', 'error');
    }
  };

  const handleSendOtp = () => {
    setOtpSent(true);
    showToast('6-digit COD verification OTP sent to ' + formData.phone, 'success');
  };

  const handleCompleteOrder = () => {
    if (!validateAddressForm()) {
      showToast('Please correct the highlighted delivery address fields', 'error');
      const section = document.getElementById('delivery-section');
      if (section) section.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }

    if (paymentMethod === 'cod') {
      if (!isCodEligible) {
        showToast(`COD limit is ${formatPrice(codMaxLimit)}. Please choose Instant UPI or Card.`, 'error');
        return;
      }
      if (!otpSent) {
        showToast('Please click "Send OTP" to verify your COD mobile number.', 'error');
        return;
      }
      if (!otpCode || otpCode.trim().length < 4) {
        showToast('Please enter the 6-digit COD verification OTP (Test code: 123456)', 'error');
        return;
      }
    }

    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      const generatedOrderNum = `VK-IN-${Math.floor(100000 + Math.random() * 900000)}`;
      const waybillNum = `BLR-${Math.floor(10000000 + Math.random() * 90000000)}`;
      setOrderNumber(generatedOrderNum);

      const orderData = {
        id: generatedOrderNum,
        orderNumber: generatedOrderNum,
        waybill: waybillNum,
        date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
        items: [...cart],
        itemCount: cart.reduce((tot, i) => tot + i.quantity, 0),
        total: cartTotalINR,
        subtotal: cartSubtotalINR,
        discount: discountAmountINR,
        discountCode: discountCode || null,
        shipping: shippingAmountINR,
        paymentMethod,
        shippingMethod: shippingMethod === 'bluedart_air' ? 'BlueDart Air Express (Fastest)' : 'Delhivery Express Priority',
        carrier: shippingMethod === 'bluedart_air' ? 'BlueDart' : 'Delhivery',
        status: 'In Transit',
        address: { ...formData },
        estimatedDelivery: '2–3 Days'
      };

      if (setTrackedOrder) {
        setTrackedOrder(orderData);
      }
      try {
        localStorage.setItem('vk_active_order', JSON.stringify(orderData));
      } catch (e) {
        console.error(e);
      }

      setStep(4);
      clearCart();

      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 120,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#D4FF00', '#FF5500', '#FFFFFF', '#0D0D11', '#10B981']
        });
      } catch (e) {
        console.error(e);
      }

      showToast('Order confirmed! Live BlueDart telemetry linked.', 'success');
    }, 600);
  };

  // If order confirmed
  if (step === 4) {
    return (
      <div className="pt-12 pb-24 max-w-3xl mx-auto px-4 sm:px-6 animate-fade-in text-center space-y-8">
        <div className="w-20 h-20 mx-auto rounded-3xl bg-volt/10 border border-volt/30 flex items-center justify-center text-volt shadow-volt-glow">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div className="space-y-3">
          <span className="text-xs font-mono font-bold text-volt uppercase tracking-widest">
            ORDER CONFIRMED & SERIALIZED FOR INDIA
          </span>
          <h1 className="font-heading font-black text-3xl sm:text-5xl text-white">
            DHANYAVAAD! YOUR ORDER IS SECURED
          </h1>
          <p className="text-sm text-zinc-400 font-normal max-w-md mx-auto">
            Your kicks are being hand-inspected, NFC-chipped, and packaged at our Bengaluru Flagship Logistics Center for express courier dispatch.
          </p>
        </div>

        {/* Order Details Card */}
        <div className="rounded-3xl glass-panel p-6 sm:p-8 border border-white/10 text-left space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-white/10">
            <div>
              <span className="text-[11px] font-mono text-zinc-400">ORDER NUMBER</span>
              <div className="text-xl font-mono font-black text-white">{orderNumber}</div>
            </div>
            <div>
              <span className="text-[11px] font-mono text-zinc-400">ESTIMATED DELIVERY</span>
              <div className="text-sm font-mono font-bold text-volt">2–3 Days (BlueDart Air)</div>
            </div>
            <div>
              <span className="text-[11px] font-mono text-zinc-400">DESTINATION</span>
              <div className="text-xs font-mono text-white">{formData.city}, {formData.pincode}</div>
            </div>
            <div>
              <span className="text-[11px] font-mono text-zinc-400">PAYMENT STATUS</span>
              <div className="text-xs font-mono text-emerald-400 font-bold">
                {paymentMethod === 'cod' ? 'Cash on Delivery (Pending Delivery)' : 'Paid Online (GST Invoice Attached)'}
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold text-zinc-400 uppercase">
              Next Steps & Real-Time Tracking:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3.5 rounded-xl bg-graphite-400 border border-white/5 space-y-1">
                <span className="text-volt font-bold">1. SMS / WhatsApp Receipt</span>
                <p className="text-zinc-400 text-[11px]">Tax invoice and tracking link sent to {formData.phone}</p>
              </div>
              <div className="p-3.5 rounded-xl bg-graphite-400 border border-white/5 space-y-1">
                <span className="text-volt font-bold">2. NFC Pairing</span>
                <p className="text-zinc-400 text-[11px]">Individual NFC chip serialized at Bengaluru Logistics Hub</p>
              </div>
              <div className="p-3.5 rounded-xl bg-graphite-400 border border-white/5 space-y-1">
                <span className="text-volt font-bold">3. Express Flight</span>
                <p className="text-zinc-400 text-[11px]">Live BlueDart / Delhivery telemetry available in 4 hours</p>
              </div>
            </div>
          </div>

          {/* GST Corporate Info */}
          <div className="p-3.5 rounded-xl bg-graphite-600 border border-white/5 text-[11px] font-mono text-zinc-400 flex items-center justify-between">
            <span>GSTIN: 29AAACV4120K1ZX • Velocity Kicks Retail India Pvt. Ltd.</span>
            <span className="text-volt">Official Tax Invoice Generated</span>
          </div>
        </div>

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => setIsOrderTrackerOpen(true)}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-xs uppercase tracking-wider shadow-volt-glow flex items-center justify-center gap-2"
          >
            <Truck className="w-4 h-4" />
            <span>Track Order Telemetry Live</span>
          </button>
          <button
            onClick={() => {
              setCurrentView('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="w-full sm:w-auto px-8 py-4 rounded-xl glass-panel-light text-white font-mono text-xs font-bold border border-white/10 hover:bg-white/10"
          >
            Return to Velocity Home
          </button>
          <button
            onClick={() => {
              setCurrentView('catalog');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="w-full sm:w-auto px-8 py-4 rounded-xl glass-panel-light text-white font-mono text-xs font-bold border border-white/10 hover:bg-white/10"
          >
            Explore More Kicks
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-8 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-fade-in">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('catalog')}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-heading font-black text-2xl sm:text-3xl text-white">
              INDIAN EXPRESS CHECKOUT
            </h1>
            <p className="text-xs font-mono text-zinc-400">
              Instant UPI • Cash on Delivery • 20,000+ Pincodes • 256-Bit SSL Encrypted
            </p>
          </div>
        </div>

        {/* Step Indicator */}
        <div className="hidden sm:flex items-center gap-2">
          {['Delivery Address', 'Carriers', 'Payment & UPI'].map((label, idx) => {
            const stepNum = idx + 1;
            return (
              <div key={label} className="flex items-center gap-2">
                <span
                  className={`w-6 h-6 rounded-full text-xs font-mono font-bold flex items-center justify-center ${
                    step >= stepNum
                      ? 'bg-volt text-graphite'
                      : 'bg-graphite-400 text-zinc-500'
                  }`}
                >
                  {stepNum}
                </span>
                <span
                  className={`text-xs font-mono ${
                    step >= stepNum ? 'text-white font-bold' : 'text-zinc-500'
                  }`}
                >
                  {label}
                </span>
                {idx < 2 && <span className="text-zinc-600">—</span>}
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Layout: Checkout Form + Order Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Left Form Steps */}
        <div className="lg:col-span-7 space-y-8">
          
          {/* Step 1: Contact & Delivery Address (India-Specific) */}
          <div id="delivery-section" className="rounded-3xl glass-panel p-6 sm:p-8 border border-white/10 space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-volt/10 text-volt flex items-center justify-center font-mono font-bold text-xs">
                  1
                </div>
                <h3 className="font-heading font-bold text-base text-white">
                  Customer Contact & Indian Delivery Address
                </h3>
              </div>
              <span className="text-xs font-mono text-volt bg-volt/10 px-2 py-0.5 rounded">
                Pan-India Express
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">Full Name *</label>
                <div className="relative">
                  <User className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-graphite-400 border text-white text-xs font-mono focus:outline-none ${
                      errors.fullName ? 'border-amber-400 focus:border-amber-400' : 'border-white/10 focus:border-volt'
                    }`}
                  />
                </div>
                {errors.fullName && (
                  <p className="text-[11px] font-mono text-amber-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 text-amber-400 flex-shrink-0" />
                    <span>{errors.fullName}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">10-Digit Mobile (For Delivery OTP) *</label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-graphite-400 border text-white text-xs font-mono focus:outline-none ${
                      errors.phone ? 'border-amber-400 focus:border-amber-400' : 'border-white/10 focus:border-volt'
                    }`}
                  />
                </div>
                {errors.phone && (
                  <p className="text-[11px] font-mono text-amber-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 text-amber-400 flex-shrink-0" />
                    <span>{errors.phone}</span>
                  </p>
                )}
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">Email Address (For GST Tax Invoice) *</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-graphite-400 border text-white text-xs font-mono focus:outline-none ${
                      errors.email ? 'border-amber-400 focus:border-amber-400' : 'border-white/10 focus:border-volt'
                    }`}
                  />
                </div>
                {errors.email && (
                  <p className="text-[11px] font-mono text-amber-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 text-amber-400 flex-shrink-0" />
                    <span>{errors.email}</span>
                  </p>
                )}
              </div>

              {/* 6-Digit Indian Pincode */}
              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">6-Digit Pincode *</label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-volt absolute left-3.5 top-3" />
                  <input
                    type="text"
                    name="pincode"
                    maxLength={6}
                    value={formData.pincode}
                    onChange={handlePincodeChange}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-graphite-400 border text-white text-xs font-mono focus:outline-none tracking-widest font-bold ${
                      errors.pincode ? 'border-amber-400 focus:border-amber-400' : 'border-white/10 focus:border-volt'
                    }`}
                  />
                </div>
                {errors.pincode && (
                  <p className="text-[11px] font-mono text-amber-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 text-amber-400 flex-shrink-0" />
                    <span>{errors.pincode}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">City / District *</label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-graphite-400 border text-white text-xs font-mono focus:outline-none ${
                    errors.city ? 'border-amber-400 focus:border-amber-400' : 'border-white/10 focus:border-volt'
                  }`}
                />
                {errors.city && (
                  <p className="text-[11px] font-mono text-amber-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 text-amber-400 flex-shrink-0" />
                    <span>{errors.city}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">State *</label>
                <select
                  name="state"
                  value={formData.state}
                  onChange={handleChange}
                  className="w-full px-3 py-2.5 rounded-xl bg-graphite-400 border border-white/10 text-white text-xs font-mono focus:border-volt focus:outline-none"
                >
                  {INDIAN_STATES.map((st) => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">Flat, House No., Building *</label>
                <input
                  type="text"
                  name="flatHouse"
                  value={formData.flatHouse}
                  onChange={handleChange}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-graphite-400 border text-white text-xs font-mono focus:outline-none ${
                    errors.flatHouse ? 'border-amber-400 focus:border-amber-400' : 'border-white/10 focus:border-volt'
                  }`}
                />
                {errors.flatHouse && (
                  <p className="text-[11px] font-mono text-amber-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 text-amber-400 flex-shrink-0" />
                    <span>{errors.flatHouse}</span>
                  </p>
                )}
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">Street Address, Colony / Area *</label>
                <input
                  type="text"
                  name="streetAddress"
                  value={formData.streetAddress}
                  onChange={handleChange}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-graphite-400 border text-white text-xs font-mono focus:outline-none ${
                    errors.streetAddress ? 'border-amber-400 focus:border-amber-400' : 'border-white/10 focus:border-volt'
                  }`}
                />
                {errors.streetAddress && (
                  <p className="text-[11px] font-mono text-amber-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 text-amber-400 flex-shrink-0" />
                    <span>{errors.streetAddress}</span>
                  </p>
                )}
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">Landmark (Optional)</label>
                <input
                  type="text"
                  name="landmark"
                  value={formData.landmark}
                  onChange={handleChange}
                  placeholder="e.g. Near Indiranagar Metro Station"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-graphite-400 border border-white/10 text-white text-xs font-mono focus:border-volt focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Step 2: Shipping Method across 20,000+ Indian Pincodes */}
          <div className="rounded-3xl glass-panel p-6 sm:p-8 border border-white/10 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-volt/10 text-volt flex items-center justify-center font-mono font-bold text-xs">
                2
              </div>
              <h3 className="font-heading font-bold text-base text-white">
                Carrier & Express Indian Logistics
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setShippingMethod('bluedart_air')}
                className={`p-3.5 rounded-2xl text-left border transition-all ${
                  shippingMethod === 'bluedart_air'
                    ? 'border-volt bg-volt/10 text-white ring-1 ring-volt'
                    : 'border-white/10 bg-graphite-400 text-zinc-300'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-heading font-bold text-xs flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-volt" />
                    <span>BlueDart Air Express (Fastest)</span>
                  </span>
                  <span className="text-volt font-mono font-bold text-xs">
                    {shippingAmountINR === 0 ? 'FREE' : formatPrice(shippingAmountINR)}
                  </span>
                </div>
                <p className="text-[11px] font-mono text-zinc-400 mt-1">2–3 Days Direct Air Cargo across Delhi NCR, Mumbai, Bengaluru, etc.</p>
              </button>

              <button
                type="button"
                onClick={() => setShippingMethod('delhivery_surface')}
                className={`p-3.5 rounded-2xl text-left border transition-all ${
                  shippingMethod === 'delhivery_surface'
                    ? 'border-volt bg-volt/10 text-white ring-1 ring-volt'
                    : 'border-white/10 bg-graphite-400 text-zinc-300'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-heading font-bold text-xs flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-zinc-400" />
                    <span>Delhivery Express Priority</span>
                  </span>
                  <span className="text-zinc-300 font-mono font-bold text-xs">
                    {shippingAmountINR === 0 ? 'FREE' : formatPrice(shippingAmountINR)}
                  </span>
                </div>
                <p className="text-[11px] font-mono text-zinc-400 mt-1">3–5 Days Secure Surface Delivery across 20,000+ Pincodes</p>
              </button>
            </div>
          </div>

          {/* Step 3: Indian Payment Gateway (UPI First, COD, No-Cost EMI, Card) */}
          <div className="rounded-3xl glass-panel p-6 sm:p-8 border border-white/10 space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-volt/10 text-volt flex items-center justify-center font-mono font-bold text-xs">
                  3
                </div>
                <h3 className="font-heading font-bold text-base text-white">
                  Payment Gateway (UPI First & COD)
                </h3>
              </div>
              <span className="text-xs font-mono text-volt bg-volt/10 px-2 py-0.5 rounded flex items-center gap-1">
                <Lock className="w-3 h-3" />
                RBI & NPCI Compliant
              </span>
            </div>

            {/* Payment Method Selector Tabs */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'upi', label: 'UPI / QR', icon: QrCode, badge: 'Popular' },
                { id: 'cod', label: 'Cash on Delivery', icon: Truck, badge: isCodEligible ? 'Active' : 'Max ₹9,999' },
                { id: 'emi', label: 'No-Cost EMI', icon: Sparkles, badge: '0%' },
                { id: 'card', label: 'Cards / NetBank', icon: CreditCard }
              ].map((p) => {
                const IconComponent = p.icon;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPaymentMethod(p.id)}
                    className={`p-3 rounded-xl text-xs font-mono font-bold border transition-all flex flex-col items-center gap-1.5 relative ${
                      paymentMethod === p.id
                        ? 'border-volt bg-volt/15 text-volt ring-1 ring-volt shadow-sm'
                        : 'border-white/10 bg-graphite-400 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {p.badge && (
                      <span className={`absolute -top-2 right-2 text-[9px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                        p.badge === 'Active' || p.badge === 'Popular'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-white/10 text-zinc-400'
                      }`}>
                        {p.badge}
                      </span>
                    )}
                    <IconComponent className="w-4 h-4" />
                    <span>{p.label}</span>
                  </button>
                );
              })}
            </div>

            {/* TAB 1: UPI FIRST INTEGRATION */}
            {paymentMethod === 'upi' && (
              <div className="p-5 rounded-2xl bg-graphite-400/90 border border-white/5 space-y-4 animate-fade-in">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <QrCode className="w-4 h-4 text-volt" />
                    Instant UPI Payments
                  </span>
                  <span className="text-[11px] font-mono text-volt bg-volt/10 px-2 py-0.5 rounded">
                    Zero Surcharge
                  </span>
                </div>

                {/* Visual UPI Apps Selection */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'gpay', name: 'Google Pay', color: 'border-blue-400/40 text-blue-300' },
                    { id: 'phonepe', name: 'PhonePe', color: 'border-purple-400/40 text-purple-300' },
                    { id: 'paytm', name: 'Paytm UPI', color: 'border-sky-400/40 text-sky-300' },
                    { id: 'qr', name: 'Direct QR Scan', color: 'border-volt/40 text-volt' }
                  ].map((app) => (
                    <button
                      key={app.id}
                      type="button"
                      onClick={() => setSelectedUpiApp(app.id)}
                      className={`p-2.5 rounded-xl border text-xs font-mono font-bold transition-all text-center ${
                        selectedUpiApp === app.id
                          ? 'bg-white/10 border-volt ring-1 ring-volt text-white'
                          : 'bg-graphite-600 border-white/5 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {app.name}
                    </button>
                  ))}
                </div>

                {/* Direct Dynamic UPI QR Code Display Preview */}
                <div className="p-4 rounded-xl bg-graphite-600 border border-white/10 flex flex-col sm:flex-row items-center gap-4">
                  {/* Generated QR Mockup */}
                  <div className="w-32 h-32 bg-white p-2 rounded-xl flex-shrink-0 flex flex-col items-center justify-center relative shadow-lg">
                    {/* SVG Stylized QR Pattern */}
                    <div className="w-full h-full border-2 border-black p-1 flex flex-col justify-between">
                      <div className="flex justify-between">
                        <div className="w-6 h-6 bg-black" />
                        <div className="w-6 h-6 bg-black" />
                      </div>
                      <div className="text-center font-black text-[9px] text-black tracking-tight">
                        UPI: VELOCITY
                      </div>
                      <div className="flex justify-between items-end">
                        <div className="w-6 h-6 bg-black" />
                        <div className="w-4 h-4 bg-black" />
                      </div>
                    </div>
                  </div>

                  {/* QR Details */}
                  <div className="min-w-0 flex-1 space-y-1.5 text-center sm:text-left">
                    <span className="text-xs font-mono font-bold text-white flex items-center justify-center sm:justify-start gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-volt animate-ping" />
                      Scan with any UPI App (GPay, PhonePe, Paytm, BHIM)
                    </span>
                    <p className="text-[11px] font-mono text-zinc-400">
                      Amount Payable: <strong className="text-volt">{formatPrice(cartTotalINR)}</strong> (Incl. GST)
                    </p>
                    <p className="text-[10px] font-mono text-zinc-500">
                      UPI Reference ID: <span className="text-zinc-300">velocitykicks.retail@icici</span>
                    </p>
                    <div className="pt-1 flex items-center justify-center sm:justify-start gap-2">
                      <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                        Auto-detects Approval
                      </span>
                      <span className="text-[10px] font-mono text-zinc-500">Valid: 09:59</span>
                    </div>
                  </div>
                </div>

                {/* Or Custom UPI ID Input */}
                <div className="pt-2 space-y-2">
                  <label className="block text-xs font-mono text-zinc-400">Or Pay via UPI ID / VPA:</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. mobile@upi or name@okhdfcbank"
                      value={customUpiId}
                      onChange={(e) => {
                        setCustomUpiId(e.target.value);
                        setUpiVerified(false);
                      }}
                      className="flex-1 px-3.5 py-2.5 rounded-xl bg-graphite-600 border border-white/10 text-white font-mono text-xs focus:border-volt focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyUpi}
                      className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs font-bold border border-white/10"
                    >
                      {upiVerified ? '✓ Verified' : 'Verify'}
                    </button>
                  </div>
                  {upiVerified && (
                    <p className="text-[11px] font-mono text-emerald-400">
                      ✓ UPI ID verified! Payment request will be pushed upon clicking Authorize.
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: CASH ON DELIVERY (COD) */}
            {paymentMethod === 'cod' && (
              <div className="p-5 rounded-2xl bg-graphite-400/90 border border-white/5 space-y-4 animate-fade-in">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-emerald-400" />
                    Cash on Delivery (Doorstep Verification)
                  </span>
                  <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${
                    isCodEligible ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    {isCodEligible ? 'COD Available' : 'COD Limit Exceeded'}
                  </span>
                </div>

                {isCodEligible ? (
                  <div className="space-y-3 text-xs font-mono">
                    <p className="text-zinc-300">
                      Pay <strong className="text-volt">{formatPrice(cartTotalINR)}</strong> in cash or via UPI QR to the BlueDart courier upon delivery.
                    </p>

                    <div className="p-3.5 rounded-xl bg-graphite-600 border border-white/5 space-y-2">
                      <span className="text-zinc-400 text-[11px] block">
                        To prevent fraudulent deliveries, please verify your mobile number:
                      </span>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          maxLength={6}
                          placeholder="Enter 6-digit SMS OTP"
                          value={otpCode}
                          onChange={(e) => setOtpCode(e.target.value)}
                          className="flex-1 px-3.5 py-2 rounded-xl bg-graphite-400 border border-white/10 text-white font-mono text-xs focus:border-volt focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={handleSendOtp}
                          className="px-4 py-2 rounded-xl bg-volt text-graphite font-heading font-bold text-xs uppercase"
                        >
                          {otpSent ? 'Resend OTP' : 'Send OTP'}
                        </button>
                      </div>
                      {otpSent && (
                        <p className="text-[11px] text-emerald-400">
                          ✓ OTP sent to {formData.phone} (Test simulator code: 123456)
                        </p>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-500/30 text-xs font-mono space-y-2 text-amber-200">
                    <div className="flex items-center gap-2 font-bold text-amber-400">
                      <AlertCircle className="w-4 h-4" />
                      <span>COD is restricted to orders up to {formatPrice(codMaxLimit)}</span>
                    </div>
                    <p className="text-[11px]">
                      Your order total is {formatPrice(cartTotalINR)}. Due to high-value prototype security, please choose Instant UPI or Card payment. Use promo code <strong className="text-volt">UPI5</strong> for 5% extra discount!
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: NO-COST EMI */}
            {paymentMethod === 'emi' && (
              <div className="p-5 rounded-2xl bg-graphite-400/90 border border-white/5 space-y-4 animate-fade-in text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-volt" />
                    No-Cost EMI & BNPL Partners
                  </span>
                  <span className="text-volt font-bold">0% Interest</span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {[
                    { months: 3, amount: Math.round(cartTotalINR / 3) },
                    { months: 6, amount: Math.round(cartTotalINR / 6) },
                    { months: 9, amount: Math.round(cartTotalINR / 9) }
                  ].map((plan) => (
                    <button
                      key={plan.months}
                      type="button"
                      onClick={() => setSelectedEmiTenure(plan.months)}
                      className={`p-3 rounded-xl border text-center transition-all ${
                        selectedEmiTenure === plan.months
                          ? 'border-volt bg-volt/15 text-white ring-1 ring-volt'
                          : 'border-white/5 bg-graphite-600 text-zinc-400'
                      }`}
                    >
                      <span className="block font-bold text-sm text-volt">{formatPrice(plan.amount)}</span>
                      <span className="text-[10px] text-zinc-400">x {plan.months} Months</span>
                    </button>
                  ))}
                </div>

                <div className="p-3 rounded-xl bg-graphite-600 border border-white/5 space-y-1">
                  <span className="text-zinc-400 text-[11px] block">Eligible EMI Partners:</span>
                  <p className="text-zinc-200 font-bold">
                    Bajaj Finserv, ZestMoney, Simpl, LazyPay, HDFC, ICICI, SBI & Axis Bank
                  </p>
                </div>
              </div>
            )}

            {/* TAB 4: CARDS & NET BANKING */}
            {paymentMethod === 'card' && (
              <div className="p-5 rounded-2xl bg-graphite-400/90 border border-white/5 space-y-4 animate-fade-in text-xs font-mono">
                <div>
                  <label className="block text-zinc-400 mb-1.5">Card Number (Visa / RuPay / Mastercard)</label>
                  <div className="relative">
                    <CreditCard className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      name="cardNumber"
                      value={formData.cardNumber}
                      onChange={handleChange}
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-graphite-600 border border-white/10 text-white focus:border-volt focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-zinc-400 mb-1.5">Expiry</label>
                    <input
                      type="text"
                      name="cardExpiry"
                      value={formData.cardExpiry}
                      onChange={handleChange}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-graphite-600 border border-white/10 text-white focus:border-volt focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-zinc-400 mb-1.5">CVV (3 Digits)</label>
                    <input
                      type="text"
                      name="cardCvc"
                      value={formData.cardCvc}
                      onChange={handleChange}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-graphite-600 border border-white/10 text-white focus:border-volt focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Complete Purchase Button */}
            <button
              onClick={handleCompleteOrder}
              disabled={isProcessing || (paymentMethod === 'cod' && !isCodEligible)}
              className={`w-full py-4 rounded-xl font-heading font-black text-sm uppercase tracking-wider shadow-volt-glow transition-all flex items-center justify-center gap-2 active:scale-95 shimmer-btn ${
                (paymentMethod === 'cod' && !isCodEligible) || isProcessing
                  ? 'bg-zinc-700 text-zinc-400 cursor-not-allowed opacity-50'
                  : 'bg-volt hover:bg-volt-light text-graphite'
              }`}
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-volt" />
                  <span>Securing Order on BlueDart Logistics...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 text-graphite" />
                  <span>
                    {paymentMethod === 'cod'
                      ? `Confirm Cash on Delivery Order • ${formatPrice(cartTotalINR)}`
                      : `Authorize & Place Order • ${formatPrice(cartTotalINR)}`}
                  </span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Right Sidebar: Order Summary */}
        <div className="lg:col-span-5">
          <div className="rounded-3xl glass-panel p-6 sm:p-8 border border-white/10 sticky top-28 space-y-6">
            <h3 className="font-heading font-black text-lg text-white pb-4 border-b border-white/10 flex items-center justify-between">
              <span>ORDER SUMMARY ({cart.reduce((t, i) => t + i.quantity, 0)})</span>
              <span className="text-xs font-mono font-normal text-volt">INR / ₹</span>
            </h3>

            {/* Item Mini List */}
            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {cart.map((item) => (
                <div
                  key={`${item.id}-${item.size}-${item.color}`}
                  className="flex items-center gap-3 p-2.5 rounded-xl bg-graphite-400/70 border border-white/5"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-14 h-14 rounded-lg object-contain bg-graphite-300 p-1 flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h5 className="font-heading font-bold text-xs text-white truncate">
                      {item.name}
                    </h5>
                    <span className="text-[11px] font-mono text-zinc-400 block">
                      Size: {item.sizeStandard || 'UK/IND'} {item.size} • Qty: {item.quantity}
                    </span>
                    <span className="text-xs font-mono font-bold text-white">
                      {formatPrice(item.price * item.quantity)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Calculations Breakdown */}
            <div className="space-y-2 text-xs font-mono pt-4 border-t border-white/10">
              <div className="flex justify-between text-zinc-400">
                <span>Subtotal</span>
                <span className="text-white">{formatPrice(cartSubtotalINR)}</span>
              </div>

              {discountPercent > 0 && (
                <div className="flex justify-between text-volt">
                  <span>Discount ({discountCode})</span>
                  <span>-{formatPrice(discountAmountINR)}</span>
                </div>
              )}

              <div className="flex justify-between text-zinc-400">
                <span>Express Courier (BlueDart / Delhivery)</span>
                <span className="text-white">
                  {shippingAmountINR === 0 ? <strong className="text-volt font-bold">FREE</strong> : formatPrice(shippingAmountINR)}
                </span>
              </div>

              {/* GST Transparency */}
              <div className="flex justify-between text-zinc-400 text-[11px]">
                <span>Taxes (GST 18%)</span>
                <span className="text-zinc-300">₹0 (Incl. of all taxes)</span>
              </div>

              <div className="flex justify-between text-base font-heading font-black text-white pt-3 border-t border-white/10">
                <div>
                  <span>Total Amount</span>
                  <span className="block text-[10px] font-mono text-zinc-400 font-normal">
                    Incl. of all taxes (GST)
                  </span>
                </div>
                <span className="text-volt text-xl">{formatPrice(cartTotalINR)}</span>
              </div>
            </div>

            {/* Indian Trust & Quality Badges */}
            <div className="space-y-2 pt-2">
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/5 flex items-center gap-3 text-xs font-mono text-zinc-400">
                <ShieldCheck className="w-5 h-5 text-volt flex-shrink-0" />
                <span>100% Authentic with tamper-evident NFC serial chip & ISO 9001 certified.</span>
              </div>
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/5 flex items-center gap-3 text-xs font-mono text-zinc-400">
                <Truck className="w-5 h-5 text-volt flex-shrink-0" />
                <span>Express Air Delivery across 20,000+ Indian pincodes with live GPS tracking.</span>
              </div>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
