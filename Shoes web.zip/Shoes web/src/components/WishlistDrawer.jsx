import React from 'react';
import { useShop } from '../context/ShopContext';
import { X, Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';

export const WishlistDrawer = () => {
  const {
    isWishlistOpen,
    setIsWishlistOpen,
    wishlist,
    toggleWishlist,
    PRODUCTS,
    addToCart,
    navigateToPdp,
    formatPrice
  } = useShop();

  if (!isWishlistOpen) return null;

  const wishlistedProducts = PRODUCTS.filter((p) => wishlist.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fade-in">
      <div
        onClick={() => setIsWishlistOpen(false)}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-graphite-500 border-l border-white/10 shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-neonOrange/10 border border-neonOrange/20 flex items-center justify-center text-neonOrange">
                <Heart className="w-4 h-4 fill-current" />
              </div>
              <div>
                <h2 className="font-heading font-black text-lg text-white">YOUR WISHLIST</h2>
                <span className="text-xs font-mono text-zinc-400">
                  {wishlist.length} saved kicks
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsWishlistOpen(false)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {wishlistedProducts.length === 0 ? (
              <div className="py-20 text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-white/5 flex items-center justify-center text-zinc-600">
                  <Heart className="w-8 h-8" />
                </div>
                <h3 className="font-heading font-bold text-lg text-white">Wishlist is Empty</h3>
                <p className="text-xs text-zinc-400 max-w-xs mx-auto">
                  Click the heart icon on any kick to save it to your personal lineup.
                </p>
                <button
                  onClick={() => setIsWishlistOpen(false)}
                  className="px-6 py-3 rounded-xl bg-volt text-graphite font-heading font-black text-xs uppercase tracking-wider"
                >
                  Explore Drops
                </button>
              </div>
            ) : (
              wishlistedProducts.map((product) => (
                <div
                  key={product.id}
                  className="p-4 rounded-2xl glass-panel-light border border-white/5 flex gap-4 items-center"
                >
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    className="w-16 h-16 rounded-xl object-contain bg-graphite-400 p-1.5 cursor-pointer"
                    onClick={() => {
                      navigateToPdp(product.id);
                      setIsWishlistOpen(false);
                    }}
                  />
                  <div className="flex-1 min-w-0">
                    <h4
                      onClick={() => {
                        navigateToPdp(product.id);
                        setIsWishlistOpen(false);
                      }}
                      className="text-xs font-bold font-heading text-white hover:text-volt cursor-pointer truncate"
                    >
                      {product.name}
                    </h4>
                    <p className="text-[11px] font-mono text-zinc-400">
                      {product.category} • {formatPrice(product.price)}
                    </p>

                    <div className="flex gap-2 mt-2">
                      <button
                        onClick={() => {
                          addToCart(product, 9, product.colors[0]?.name);
                          setIsWishlistOpen(false);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-volt hover:bg-volt-light text-graphite font-mono font-bold text-[11px] flex items-center gap-1"
                      >
                        <ShoppingBag className="w-3 h-3" />
                        <span>Move to Bag</span>
                      </button>
                      <button
                        onClick={() => toggleWishlist(product.id)}
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-zinc-400 hover:text-red-400 transition-colors"
                        title="Remove from wishlist"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="p-6 bg-graphite-400 border-t border-white/10">
            <button
              onClick={() => setIsWishlistOpen(false)}
              className="w-full py-3.5 rounded-xl bg-white/5 hover:bg-white/10 text-white font-mono text-xs font-bold border border-white/10"
            >
              Continue Browsing
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
