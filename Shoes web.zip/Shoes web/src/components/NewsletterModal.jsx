import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, Sparkles, Copy, Check, ArrowRight, ShieldCheck } from 'lucide-react';

export const NewsletterModal = () => {
  const { isNewsletterModalOpen, setIsNewsletterModalOpen, applyPromoCode, showToast } = useShop();
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isNewsletterModalOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
      applyPromoCode('FESTIVE15');
    }
  };

  const handleCopy = () => {
    navigator.clipboard?.writeText('FESTIVE15');
    setCopied(true);
    showToast('Copied code "FESTIVE15" to clipboard!', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md rounded-3xl glass-panel p-6 sm:p-8 shadow-2xl border border-white/10 space-y-6 text-center">
        
        {/* Close Button */}
        <button
          onClick={() => setIsNewsletterModalOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Visual Badge */}
        <div className="w-16 h-16 mx-auto rounded-2xl bg-volt/10 border border-volt/20 flex items-center justify-center text-volt shadow-volt-glow">
          <Sparkles className="w-8 h-8" />
        </div>

        {!isSubmitted ? (
          <>
            <div className="space-y-2">
              <span className="text-xs font-mono font-bold text-volt uppercase tracking-wider">
                DIWALI & FESTIVE DROP ACCESS
              </span>
              <h3 className="font-heading font-black text-2xl text-white">
                UNLOCK 15% OFF YOUR FESTIVE DROP
              </h3>
              <p className="text-xs text-zinc-400 max-w-xs mx-auto">
                Join 50,000+ Indian runners & streetwear purists receiving secret drop alerts, monsoon prototype releases, and member-only pricing.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <input
                type="email"
                required
                placeholder="Enter your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-graphite-400 border border-white/10 text-white text-xs font-mono focus:border-volt focus:outline-none placeholder-zinc-500 text-center"
              />
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-xs uppercase tracking-wider shadow-volt-glow transition-all"
              >
                Claim My 15% Festive Discount
              </button>
            </form>

            <div className="flex items-center justify-center gap-1.5 text-[11px] font-mono text-zinc-500">
              <ShieldCheck className="w-3.5 h-3.5 text-zinc-400" />
              <span>Zero spam. Direct WhatsApp / Email drop alerts only.</span>
            </div>
          </>
        ) : (
          <div className="space-y-4 animate-fade-in">
            <h3 className="font-heading font-black text-2xl text-white">
              YOU'RE ON THE VIP DROP LIST
            </h3>
            <p className="text-xs text-zinc-400">
              Your 15% off festive coupon code has been generated and auto-applied to your shopping bag:
            </p>

            <div className="p-4 rounded-2xl bg-graphite-400 border border-volt/30 flex items-center justify-between">
              <span className="font-mono font-black text-lg text-volt tracking-widest">
                FESTIVE15
              </span>
              <button
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg bg-volt text-graphite text-xs font-mono font-bold flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <button
              onClick={() => setIsNewsletterModalOpen(false)}
              className="w-full py-3.5 rounded-xl bg-white text-graphite font-heading font-black text-xs uppercase"
            >
              Continue Shopping With 15% Off
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
