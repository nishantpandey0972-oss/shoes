import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import {
  ArrowRight,
  ShieldCheck,
  Package,
  Ruler,
  MapPin,
  Globe,
  Sparkles,
  Zap,
  Mail,
  Phone,
  MessageCircle,
  Truck,
  RotateCcw,
  CheckCircle2
} from 'lucide-react';

export const Footer = () => {
  const {
    navigateToCatalog,
    setIsOrderTrackerOpen,
    setIsFitModalOpen,
    setIsNewsletterModalOpen,
    showToast
  } = useShop();

  const [footerEmail, setFooterEmail] = useState('');

  const handleFooterSubscribe = (e) => {
    e.preventDefault();
    if (footerEmail) {
      setIsNewsletterModalOpen(true);
    }
  };

  const handleWhatsAppChat = () => {
    showToast('Opening Velocity Kicks WhatsApp Concierge (+91 98765 43210)...', 'success');
    window.open('https://wa.me/919876543210?text=Hi%20Velocity%20Kicks%2C%20I%20have%20an%20inquiry%20about%20your%20Indian%20Drop%20Collection', '_blank');
  };

  return (
    <footer className="bg-graphite-600 border-t border-white/10 pt-16 pb-12 text-zinc-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Top Newsletter & Festive Drop Incentive Box */}
        <div className="rounded-3xl glass-card p-8 sm:p-10 border border-white/10 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="max-w-xl text-center lg:text-left space-y-2">
            <span className="text-xs font-mono font-bold text-volt uppercase tracking-wider flex items-center justify-center lg:justify-start gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              JOIN THE VELOCITY INDIA DROP NETWORK
            </span>
            <h3 className="font-heading font-black text-2xl sm:text-3xl text-white">
              GET 15% OFF YOUR FESTIVE DROP
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Gain priority queuing for Diwali carbon drops, secret midnight releases, and monsoon prototype field testing in India.
            </p>
          </div>

          <form onSubmit={handleFooterSubscribe} className="w-full lg:w-auto flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              placeholder="athlete@velocitykicks.in"
              value={footerEmail}
              onChange={(e) => setFooterEmail(e.target.value)}
              className="px-5 py-3.5 rounded-xl bg-graphite-400 border border-white/10 text-white placeholder-zinc-500 text-xs font-mono focus:border-volt focus:outline-none min-w-[260px]"
            />
            <button
              type="submit"
              className="px-7 py-3.5 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-xs uppercase tracking-wider shadow-volt-glow transition-all flex items-center justify-center gap-2 whitespace-nowrap shimmer-btn"
            >
              <span>Unlock 15% Off (Code: FESTIVE15)</span>
              <ArrowRight className="w-4 h-4 text-graphite" />
            </button>
          </form>
        </div>

        {/* WhatsApp & Indian Customer Support Highlights Bar */}
        <div className="p-6 rounded-2xl glass-panel border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 flex-shrink-0">
              <MessageCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-heading font-bold text-sm text-white">
                INSTANT WHATSAPP ATHLETE CONCIERGE
              </h4>
              <p className="text-xs font-mono text-zinc-400">
                Speak directly with an Indian footwear specialist for sizing, order tracking, and custom fit advice.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              onClick={handleWhatsAppChat}
              className="flex-1 md:flex-none px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-graphite font-heading font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95"
            >
              <MessageCircle className="w-4 h-4 text-graphite fill-current" />
              <span>Chat with us on WhatsApp (+91 98765 43210)</span>
            </button>
            <div className="hidden sm:flex items-center gap-2 px-4 py-3 rounded-xl bg-graphite-400 border border-white/5 text-xs font-mono text-zinc-300">
              <Phone className="w-3.5 h-3.5 text-volt" />
              <span>+91 (080) 4920-KICK</span>
            </div>
          </div>
        </div>

        {/* Links Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 pt-6">
          
          {/* Brand Info & India Office */}
          <div className="col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-volt flex items-center justify-center font-heading font-black text-graphite text-lg shadow-volt-glow">
                V
              </div>
              <span className="font-heading font-black tracking-tighter text-2xl text-white">
                VELOCITY <span className="text-volt">KICKS</span> <span className="text-xs font-mono font-bold text-zinc-400 ml-1">INDIA</span>
              </span>
            </div>
            <p className="text-xs text-zinc-400 max-w-sm leading-relaxed">
              Pioneering hyper-responsive carbon propulsion and supercritical cushioning systems, engineered specifically for Indian roads, monsoons, and extreme climates.
            </p>
            <div className="space-y-1 text-xs font-mono text-zinc-500 pt-1">
              <div className="flex items-center gap-2 text-zinc-400">
                <MapPin className="w-3.5 h-3.5 text-volt" />
                <span>Flagship Logistics Hub: Indiranagar, Bengaluru, KA 560038</span>
              </div>
              <div className="flex items-center gap-2 text-zinc-400">
                <Phone className="w-3.5 h-3.5 text-volt" />
                <span>Customer Care: +91 (080) 4920-KICK (Mon–Sat 9AM–8PM IST)</span>
              </div>
            </div>
          </div>

          {/* Column 1: Footwear Categories */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
              Footwear Collections
            </h4>
            <ul className="space-y-2 text-xs font-mono">
              <li>
                <button onClick={() => navigateToCatalog('Running')} className="hover:text-volt">
                  Marathon & Road Running
                </button>
              </li>
              <li>
                <button onClick={() => navigateToCatalog('Basketball')} className="hover:text-volt">
                  Court & Basketball Kicks
                </button>
              </li>
              <li>
                <button onClick={() => navigateToCatalog('Limited Drops')} className="hover:text-volt flex items-center gap-1.5">
                  <span>Diwali Fest Drops</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] bg-neonOrange text-white font-bold">HOT</span>
                </button>
              </li>
              <li>
                <button onClick={() => navigateToCatalog('Boots')} className="hover:text-volt">
                  Monsoon Terrain Boots
                </button>
              </li>
              <li>
                <button onClick={() => navigateToCatalog('Casual')} className="hover:text-volt">
                  Urban Indian Streetwear
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Athlete Support & Indian Tools */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
              Support & Tools
            </h4>
            <ul className="space-y-2 text-xs font-mono">
              <li>
                <button
                  onClick={() => setIsOrderTrackerOpen(true)}
                  className="hover:text-volt flex items-center gap-1.5"
                >
                  <Package className="w-3 h-3 text-volt" />
                  <span>BlueDart / Delhivery Tracker</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setIsFitModalOpen(true)}
                  className="hover:text-volt flex items-center gap-1.5"
                >
                  <Ruler className="w-3 h-3 text-volt" />
                  <span>UK / India Size Assistant</span>
                </button>
              </li>
              <li>
                <span className="text-zinc-500">
                  Easy 7-Day Doorstep Returns
                </span>
              </li>
              <li>
                <span className="text-zinc-500">
                  Cash on Delivery (COD Rules)
                </span>
              </li>
              <li>
                <span className="text-zinc-500">
                  Carbon Warranty & NFC Auth
                </span>
              </li>
            </ul>
          </div>

          {/* Column 3: Corporate & GSTIN Legal Details */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
              Legal & Compliance
            </h4>
            <ul className="space-y-2 text-xs font-mono">
              <li>
                <span className="text-zinc-300 font-bold">GSTIN: 29AAACV4120K1ZX</span>
              </li>
              <li>
                <span className="text-zinc-400">CIN: U52100KA2024PTC184920</span>
              </li>
              <li>
                <span className="text-zinc-500">ISO 9001:2015 Certified Quality</span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Consumer Grievance Redressal</span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Indian E-Commerce Terms</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Strip with Indian Payment Methods & Legal Notice */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono text-zinc-500">
          <div>
            <p>© {new Date().getFullYear()} VELOCITY KICKS RETAIL INDIA PVT. LTD. ALL RIGHTS RESERVED.</p>
            <p className="text-[10px] text-zinc-600 mt-0.5">
              Registered Office: #402 Prestige Cyber Towers, 100 Feet Road, HAL 2nd Stage, Indiranagar, Bengaluru, Karnataka 560038
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 text-[11px] text-zinc-400">
            <span className="text-white font-bold">UPI First</span>
            <span>•</span>
            <span className="text-blue-400 font-bold">Google Pay</span>
            <span>•</span>
            <span className="text-purple-400 font-bold">PhonePe</span>
            <span>•</span>
            <span className="text-sky-400 font-bold">Paytm</span>
            <span>•</span>
            <span className="text-emerald-400 font-bold">RuPay</span>
            <span>•</span>
            <span>Cash on Delivery</span>
            <span>•</span>
            <span>Bajaj Finserv EMI</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
