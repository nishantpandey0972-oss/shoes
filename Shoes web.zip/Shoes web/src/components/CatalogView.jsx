import React, { useState, useMemo } from 'react';
import { useShop } from '../context/ShopContext';
import { ProductCard } from './ProductCard';
import {
  Filter,
  SlidersHorizontal,
  X,
  ChevronDown,
  RotateCcw,
  Sparkles,
  ArrowUpDown,
  Truck,
  CheckCircle2,
  CloudRain
} from 'lucide-react';

const CATEGORIES = ['All', 'Running', 'Basketball', 'Casual', 'Boots', 'Performance', 'Limited Drops'];
const GENDERS = ['All', 'Men', 'Women', 'Unisex'];
const UK_SIZES = [4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11];
const COLOR_OPTIONS = [
  { name: 'Volt Lime', hex: '#D4FF00' },
  { name: 'Blaze Saffron', hex: '#FF5500' },
  { name: 'Festive Gold', hex: '#E5A93C' },
  { name: 'Stealth Black', hex: '#0D0D11' },
  { name: 'Pure White', hex: '#FFFFFF' },
  { name: 'Desert Olive', hex: '#9E9EB0' }
];

export const CatalogView = () => {
  const {
    PRODUCTS,
    catalogCategory,
    setCatalogCategory,
    formatPrice,
    sizeStandard,
    setSizeStandard
  } = useShop();

  const [selectedGender, setSelectedGender] = useState('All');
  const [selectedSizes, setSelectedSizes] = useState([]);
  const [selectedColors, setSelectedColors] = useState([]);
  const [priceRange, setPriceRange] = useState(25000); // Up to ₹25,000 INR
  const [inStockOnly, setInStockOnly] = useState(false);
  const [codOnly, setCodOnly] = useState(false);
  const [sortBy, setSortBy] = useState('featured');
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Toggle size
  const toggleSize = (size) => {
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
  };

  // Toggle color
  const toggleColor = (colorName) => {
    setSelectedColors((prev) =>
      prev.includes(colorName) ? prev.filter((c) => c !== colorName) : [...prev, colorName]
    );
  };

  // Reset filters
  const resetFilters = () => {
    setCatalogCategory('All');
    setSelectedGender('All');
    setSelectedSizes([]);
    setSelectedColors([]);
    setPriceRange(25000);
    setInStockOnly(false);
    setCodOnly(false);
    setSortBy('featured');
  };

  // Filtered and Sorted list
  const filteredProducts = useMemo(() => {
    let result = [...PRODUCTS];

    // Category
    if (catalogCategory !== 'All') {
      result = result.filter((p) => p.category === catalogCategory);
    }

    // Gender
    if (selectedGender !== 'All') {
      result = result.filter((p) => p.gender === selectedGender || p.gender === 'Unisex');
    }

    // Price
    result = result.filter((p) => p.price <= priceRange);

    // In Stock
    if (inStockOnly) {
      result = result.filter((p) => p.inStock);
    }

    // COD Filter
    if (codOnly) {
      result = result.filter((p) => p.price <= 9999);
    }

    // Size filter (Matching UK/India sizes)
    if (selectedSizes.length > 0) {
      result = result.filter((p) =>
        p.sizes.some((s) => selectedSizes.includes(s.uk) && s.stock > 0)
      );
    }

    // Color filter
    if (selectedColors.length > 0) {
      result = result.filter((p) =>
        p.colors.some((c) =>
          selectedColors.some((sc) => c.name.toLowerCase().includes(sc.toLowerCase()))
        )
      );
    }

    // Sorting
    if (sortBy === 'price-low') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'newest') {
      result.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    }

    return result;
  }, [PRODUCTS, catalogCategory, selectedGender, priceRange, inStockOnly, codOnly, selectedSizes, selectedColors, sortBy]);

  const activeFilterCount =
    (catalogCategory !== 'All' ? 1 : 0) +
    (selectedGender !== 'All' ? 1 : 0) +
    selectedSizes.length +
    selectedColors.length +
    (priceRange < 25000 ? 1 : 0) +
    (inStockOnly ? 1 : 0) +
    (codOnly ? 1 : 0);

  return (
    <div className="pt-6 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
      
      {/* Top Header & Collection Hero Banner */}
      <div className="relative rounded-3xl glass-card p-8 sm:p-12 overflow-hidden border border-white/10">
        <div className="absolute top-0 right-0 w-96 h-96 bg-volt/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-0 right-1/3 w-64 h-64 bg-neonOrange/10 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="relative z-10 max-w-2xl space-y-3">
          <span className="text-xs font-mono font-bold text-volt uppercase tracking-widest flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Pan-India Footwear Catalog • 20,000+ Pincodes Covered
          </span>
          <h1 className="font-heading font-black text-3xl sm:text-5xl text-white tracking-tight">
            HIGH-PERFORMANCE LINEUP
          </h1>
          <p className="text-sm text-zinc-400 font-normal leading-relaxed">
            From Tata Mumbai Marathon carbon propulsion to monsoon-proof Western Ghats trail grip. All pricing in ₹ INR inclusive of 18% GST with Free BlueDart Express on orders above ₹2,499.
          </p>
        </div>
      </div>

      {/* Main Catalog View: Sidebar Filters + Products Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Left Desktop Sidebar Filters */}
        <div className="hidden lg:block space-y-6">
          <div className="rounded-3xl glass-panel p-6 border border-white/10 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <span className="font-heading font-bold text-base text-white flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-volt" />
                <span>Filters</span>
                {activeFilterCount > 0 && (
                  <span className="w-5 h-5 rounded-full bg-volt text-graphite text-[10px] font-mono font-bold flex items-center justify-center">
                    {activeFilterCount}
                  </span>
                )}
              </span>

              {activeFilterCount > 0 && (
                <button
                  onClick={resetFilters}
                  className="text-xs font-mono text-zinc-400 hover:text-white flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              )}
            </div>

            {/* Category Filter */}
            <div className="space-y-2.5">
              <label className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider block">
                Category
              </label>
              <div className="space-y-1">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCatalogCategory(cat)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-colors flex items-center justify-between ${
                      catalogCategory === cat
                        ? 'bg-volt text-graphite font-bold shadow-volt-glow'
                        : 'text-zinc-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span>{cat}</span>
                    <span className="text-[10px] opacity-70">
                      ({cat === 'All' ? PRODUCTS.length : PRODUCTS.filter((p) => p.category === cat).length})
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Indian COD & Stock Quick Filter Toggles */}
            <div className="space-y-2 pt-4 border-t border-white/10">
              <label className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider block">
                Payment & Availability
              </label>
              <div className="space-y-2 text-xs font-mono">
                <label className="flex items-center gap-2.5 cursor-pointer text-zinc-300 hover:text-white">
                  <input
                    type="checkbox"
                    checked={codOnly}
                    onChange={(e) => setCodOnly(e.target.checked)}
                    className="w-4 h-4 rounded bg-graphite-600 border-white/20 text-volt focus:ring-volt"
                  />
                  <span>Cash on Delivery (COD) Only</span>
                </label>
                <label className="flex items-center gap-2.5 cursor-pointer text-zinc-300 hover:text-white">
                  <input
                    type="checkbox"
                    checked={inStockOnly}
                    onChange={(e) => setInStockOnly(e.target.checked)}
                    className="w-4 h-4 rounded bg-graphite-600 border-white/20 text-volt focus:ring-volt"
                  />
                  <span>In Stock Only</span>
                </label>
              </div>
            </div>

            {/* UK / India Size Filter */}
            <div className="space-y-3 pt-4 border-t border-white/10">
              <div className="flex items-center justify-between">
                <label className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider">
                  UK / INDIA Size
                </label>
                <span className="text-[10px] font-mono text-zinc-500">Wide-Fit</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {UK_SIZES.map((sz) => (
                  <button
                    key={sz}
                    onClick={() => toggleSize(sz)}
                    className={`py-2 rounded-xl text-xs font-mono font-bold border transition-all ${
                      selectedSizes.includes(sz)
                        ? 'border-volt bg-volt text-graphite shadow-volt-glow'
                        : 'border-white/10 bg-graphite-400 text-zinc-300 hover:border-white/20'
                    }`}
                  >
                    UK {sz}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range Slider in INR */}
            <div className="space-y-3 pt-4 border-t border-white/10">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400 uppercase tracking-wider font-bold">Max Price:</span>
                <span className="text-volt font-bold">{formatPrice(priceRange)}</span>
              </div>
              <input
                type="range"
                min={2000}
                max={25000}
                step={500}
                value={priceRange}
                onChange={(e) => setPriceRange(Number(e.target.value))}
                className="w-full accent-volt cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-zinc-500">
                <span>Entry: ₹1,999</span>
                <span>Limited: ₹18,999+</span>
              </div>
            </div>

            {/* Color Swatches */}
            <div className="space-y-3 pt-4 border-t border-white/10">
              <label className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider block">
                Colorways
              </label>
              <div className="flex flex-wrap gap-2">
                {COLOR_OPTIONS.map((col) => (
                  <button
                    key={col.name}
                    onClick={() => toggleColor(col.name)}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-mono flex items-center gap-1.5 transition-all ${
                      selectedColors.includes(col.name)
                        ? 'border-volt bg-volt/15 text-volt ring-1 ring-volt'
                        : 'border-white/10 text-zinc-400 hover:border-white/20 bg-graphite-400'
                    }`}
                  >
                    <span
                      className="w-3 h-3 rounded-full border border-white/20"
                      style={{ backgroundColor: col.hex }}
                    />
                    <span>{col.name}</span>
                  </button>
                ))}
              </div>
            </div>

          </div>
        </div>

        {/* Right Product Grid & Sorting Toolbar */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Top Sorting Bar */}
          <div className="p-4 rounded-2xl glass-panel border border-white/10 flex flex-wrap items-center justify-between gap-4">
            <span className="text-xs font-mono text-zinc-400">
              Showing <strong className="text-white">{filteredProducts.length}</strong> of {PRODUCTS.length} Models
            </span>

            <div className="flex items-center gap-3">
              {/* Mobile Filter Button */}
              <button
                onClick={() => setShowMobileFilters(!showMobileFilters)}
                className="lg:hidden px-3.5 py-2 rounded-xl bg-white/10 text-white text-xs font-mono font-bold flex items-center gap-1.5"
              >
                <Filter className="w-3.5 h-3.5 text-volt" />
                <span>Filters {activeFilterCount > 0 && `(${activeFilterCount})`}</span>
              </button>

              {/* Sort By Dropdown */}
              <div className="flex items-center gap-2 text-xs font-mono">
                <ArrowUpDown className="w-3.5 h-3.5 text-volt" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-graphite-400 border border-white/10 text-white font-mono text-xs focus:border-volt focus:outline-none"
                >
                  <option value="featured">Featured Drops</option>
                  <option value="price-low">Price: Low to High (INR)</option>
                  <option value="price-high">Price: High to Low (INR)</option>
                  <option value="rating">Highest Rated</option>
                  <option value="newest">New Releases</option>
                </select>
              </div>
            </div>
          </div>

          {/* Mobile Filter Drawer Overlay if open */}
          {showMobileFilters && (
            <div className="lg:hidden p-6 rounded-3xl glass-panel border border-volt/30 space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h4 className="font-heading font-bold text-base text-white">Filter Footwear</h4>
                <button
                  onClick={() => setShowMobileFilters(false)}
                  className="p-1 rounded-lg text-zinc-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Mobile Category */}
              <div className="flex flex-wrap gap-1.5">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCatalogCategory(cat)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold ${
                      catalogCategory === cat ? 'bg-volt text-graphite' : 'bg-white/5 text-zinc-400'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Mobile Price Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span>Max Price:</span>
                  <span className="text-volt font-bold">{formatPrice(priceRange)}</span>
                </div>
                <input
                  type="range"
                  min={2000}
                  max={25000}
                  step={500}
                  value={priceRange}
                  onChange={(e) => setPriceRange(Number(e.target.value))}
                  className="w-full accent-volt"
                />
              </div>

              {/* Mobile COD Toggle */}
              <label className="flex items-center gap-2 text-xs font-mono text-zinc-300">
                <input
                  type="checkbox"
                  checked={codOnly}
                  onChange={(e) => setCodOnly(e.target.checked)}
                  className="w-4 h-4 rounded text-volt"
                />
                <span>Cash on Delivery (COD) Only</span>
              </label>

              <button
                onClick={() => setShowMobileFilters(false)}
                className="w-full py-3 rounded-xl bg-volt text-graphite font-heading font-bold text-xs uppercase"
              >
                Apply Filters ({filteredProducts.length} Results)
              </button>
            </div>
          )}

          {/* Product Cards Grid */}
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="py-20 text-center space-y-4 rounded-3xl glass-card p-12 border border-white/5">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-white/5 flex items-center justify-center text-zinc-500">
                <Filter className="w-8 h-8" />
              </div>
              <h3 className="font-heading font-bold text-xl text-white">No Models Found</h3>
              <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                No kicks matched your active filter criteria. Try adjusting your price slider or clearing size filters.
              </p>
              <button
                onClick={resetFilters}
                className="px-6 py-3 rounded-xl bg-volt text-graphite font-heading font-black text-xs uppercase tracking-wider"
              >
                Reset All Filters
              </button>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
