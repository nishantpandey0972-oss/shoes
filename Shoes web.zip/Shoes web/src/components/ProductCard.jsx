import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { Heart, Star, ShoppingBag, Eye, Zap, Flame, CheckCircle2, CloudRain } from 'lucide-react';

export const ProductCard = ({ product }) => {
  const {
    formatPrice,
    navigateToPdp,
    toggleWishlist,
    wishlist,
    setQuickAddProduct,
    setIsQuickAddOpen,
    sizeStandard
  } = useShop();

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [activeColorIndex, setActiveColorIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  const isWishlisted = wishlist.includes(product.id);

  // Badge styling
  const badgeStyles = {
    lime: 'bg-volt/15 text-volt border-volt/30',
    orange: 'bg-neonOrange/15 text-neonOrange border-neonOrange/30',
    white: 'bg-white/10 text-white border-white/20',
    red: 'bg-red-500/15 text-red-400 border-red-500/30'
  };

  const badgeClass = badgeStyles[product.badgeType] || badgeStyles.lime;

  // Dual-image swap on hover
  const currentImage = isHovered && product.images.length > 1
    ? product.images[1]
    : product.images[activeImageIndex] || product.images[0];

  const handleQuickAdd = (e) => {
    e.stopPropagation();
    setQuickAddProduct(product);
    setIsQuickAddOpen(true);
  };

  return (
    <div
      onClick={() => navigateToPdp(product.id)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative rounded-2xl glass-card overflow-hidden flex flex-col cursor-pointer transition-all duration-300 hover:border-volt/30"
    >
      {/* Top badges & Wishlist row */}
      <div className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between pointer-events-none">
        {product.badge ? (
          <span className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-bold tracking-wider uppercase border backdrop-blur-md shadow-sm ${badgeClass}`}>
            {product.badge}
          </span>
        ) : (
          <span />
        )}

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`pointer-events-auto p-2 rounded-xl backdrop-blur-md border transition-all duration-200 ${
            isWishlisted
              ? 'bg-neonOrange text-white border-neonOrange shadow-orange-glow scale-105'
              : 'bg-graphite-500/80 text-zinc-400 hover:text-white border-white/10 hover:border-white/20'
          }`}
          title="Save to Wishlist"
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Product Image Stage */}
      <div className="relative w-full aspect-square bg-gradient-to-b from-graphite-300/50 to-graphite-400/80 p-6 flex items-center justify-center overflow-hidden">
        {/* Subtle radial glow */}
        <div className="absolute inset-0 bg-radial-gradient from-white/5 to-transparent opacity-50 group-hover:opacity-100 transition-opacity" />

        <img
          src={currentImage}
          alt={product.name}
          className="w-full h-full object-contain filter drop-shadow-[0_15px_20px_rgba(0,0,0,0.7)] group-hover:scale-105 group-hover:-rotate-2 transition-transform duration-500"
        />

        {/* Stock warning pill if <= 4 items */}
        {product.stockLeft <= 4 && (
          <div className="absolute bottom-3 left-3 z-10 flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-graphite-600/90 border border-neonOrange/30 text-[10px] font-mono text-neonOrange font-semibold backdrop-blur-sm">
            <Flame className="w-3 h-3 text-neonOrange animate-pulse" />
            <span>Only {product.stockLeft} pairs left</span>
          </div>
        )}

        {/* Quick Add Overlay Button on hover */}
        <div className="absolute inset-x-3 bottom-3 z-20 flex gap-2 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
          <button
            onClick={handleQuickAdd}
            className="flex-1 py-2.5 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-xs uppercase tracking-wider shadow-volt-glow transition-all flex items-center justify-center gap-1.5"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-graphite" />
            <span>Quick Bag • {formatPrice(product.price)}</span>
          </button>
        </div>
      </div>

      {/* Product Meta Section */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Category & Rating */}
          <div className="flex items-center justify-between text-xs text-zinc-400 font-mono mb-1">
            <span>{product.category} • {product.gender}</span>
            <div className="flex items-center gap-1 text-white">
              <Star className="w-3.5 h-3.5 fill-volt text-volt" />
              <span className="font-bold text-[11px]">{product.rating}</span>
              <span className="text-zinc-500 text-[10px]">({product.reviewCount})</span>
            </div>
          </div>

          {/* Title */}
          <h3 className="font-heading font-bold text-base text-white group-hover:text-volt transition-colors line-clamp-1">
            {product.name}
          </h3>

          {/* Short tagline */}
          <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">
            {product.tagline}
          </p>

          {/* Indian feature tags */}
          <div className="flex items-center gap-2 pt-2 text-[10px] font-mono">
            {product.price <= 9999 ? (
              <span className="text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                <CheckCircle2 className="w-3 h-3" />
                COD Available
              </span>
            ) : (
              <span className="text-amber-400 flex items-center gap-1 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                <Zap className="w-3 h-3" />
                Prepaid Drop
              </span>
            )}
            <span className="text-zinc-400 bg-white/5 px-1.5 py-0.5 rounded">
              UK 6–11 Wide Fit
            </span>
          </div>
        </div>

        {/* Color variants & Price */}
        <div className="pt-2 border-t border-white/5 flex items-center justify-between">
          {/* Color swatch dots */}
          <div className="flex items-center gap-1.5">
            {product.colors.map((color, idx) => (
              <button
                key={color.name}
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveColorIndex(idx);
                }}
                className={`w-4 h-4 rounded-full border transition-all ${
                  activeColorIndex === idx
                    ? 'scale-125 border-volt ring-2 ring-volt/20'
                    : 'border-white/20 hover:scale-110'
                }`}
                style={{
                  background: `linear-gradient(135deg, ${color.hex} 50%, ${color.secondaryHex || color.hex} 50%)`
                }}
                title={color.name}
              />
            ))}
            <span className="text-[10px] text-zinc-500 font-mono ml-1">
              {product.colors.length} col
            </span>
          </div>

          {/* Price with GST hint */}
          <div className="text-right">
            <div className="flex items-baseline gap-1.5">
              {product.originalPrice && (
                <span className="text-xs font-mono text-zinc-500 line-through">
                  {formatPrice(product.originalPrice)}
                </span>
              )}
              <span className="text-base font-heading font-black text-white group-hover:text-volt transition-colors">
                {formatPrice(product.price)}
              </span>
            </div>
            <span className="text-[9px] font-mono text-zinc-500 block">
              Incl. GST
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
