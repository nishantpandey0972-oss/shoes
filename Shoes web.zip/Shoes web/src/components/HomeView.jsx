import React, { useState, useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import { Hero } from './Hero';
import { ProductCard } from './ProductCard';
import { UGC_REVIEWS } from '../data/products';
import {
  ArrowRight,
  Sparkles,
  Zap,
  ShieldCheck,
  Cpu,
  Flame,
  Clock,
  Layers,
  ChevronRight,
  Ruler,
  Star,
  CloudRain,
  Sun,
  Truck,
  HeartHandshake
} from 'lucide-react';

export const HomeView = () => {
  const {
    PRODUCTS,
    navigateToCatalog,
    navigateToPdp,
    setIsFitModalOpen,
    setIsNewsletterModalOpen,
    formatPrice
  } = useShop();

  const [activeTab, setActiveTab] = useState('All');

  // Countdown timer for next Indian drop (Diwali Midnight Gold Release)
  const [timeLeft, setTimeLeft] = useState({
    hours: 14,
    minutes: 36,
    seconds: 42
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: 59, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 24, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const featuredProducts = activeTab === 'All'
    ? PRODUCTS.slice(0, 6)
    : PRODUCTS.filter((p) => p.category === activeTab || (activeTab === 'Limited Drops' && p.isLimitedDrop)).slice(0, 6);

  return (
    <div className="space-y-20 sm:space-y-28">
      {/* Hero Showcase */}
      <Hero />

      {/* Cultural Campaign Trio Banners: Diwali Drop | Monsoon Streetwear | Wedding Sneakers */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Banner 1: Diwali Fest Drop */}
          <div
            onClick={() => navigateToCatalog('Limited Drops')}
            className="group relative rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-amber-950/40 via-graphite-400 to-graphite-500 border border-amber-500/30 overflow-hidden cursor-pointer shadow-lg hover:border-amber-400/50 transition-all"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
            <div className="space-y-3 relative z-10">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>DIWALI FEST DROP</span>
              </span>
              <h3 className="font-heading font-black text-2xl text-white group-hover:text-amber-300 transition-colors">
                FESTIVE GOLD CARBON
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Limited edition serialized releases with gold titanium lace aglets and reflective saffron accents.
              </p>
              <div className="pt-2 flex items-center gap-2 text-xs font-mono font-bold text-amber-400">
                <span>Shop Diwali Editions</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>

          {/* Banner 2: Monsoon Streetwear Collection */}
          <div
            onClick={() => navigateToCatalog('Boots')}
            className="group relative rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-cyan-950/40 via-graphite-400 to-graphite-500 border border-cyan-500/30 overflow-hidden cursor-pointer shadow-lg hover:border-cyan-400/50 transition-all"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
            <div className="space-y-3 relative z-10">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-bold">
                <CloudRain className="w-3.5 h-3.5 text-cyan-400" />
                <span>MONSOON RESISTANT</span>
              </span>
              <h3 className="font-heading font-black text-2xl text-white group-hover:text-cyan-300 transition-colors">
                WET-TERRAIN OUTSOLES
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Hydrophobic monomesh upper and Vibram Megagrip lugs engineered for Mumbai puddles and Western Ghats trails.
              </p>
              <div className="pt-2 flex items-center gap-2 text-xs font-mono font-bold text-cyan-400">
                <span>Explore Monsoon Lineup</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>

          {/* Banner 3: Wedding Season Sneakers */}
          <div
            onClick={() => navigateToCatalog('Casual')}
            className="group relative rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-rose-950/40 via-graphite-400 to-graphite-500 border border-rose-500/30 overflow-hidden cursor-pointer shadow-lg hover:border-rose-400/50 transition-all"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
            <div className="space-y-3 relative z-10">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-mono font-bold">
                <HeartHandshake className="w-3.5 h-3.5 text-rose-400" />
                <span>WEDDING SNEAKERS</span>
              </span>
              <h3 className="font-heading font-black text-2xl text-white group-hover:text-rose-300 transition-colors">
                SANGEET TO STREET
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Luxury architectural sneakers designed to pair effortlessly with bandhgalas, kurtas, and modern reception fits.
              </p>
              <div className="pt-2 flex items-center gap-2 text-xs font-mono font-bold text-rose-400">
                <span>Discover Wedding Series</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Live Drop Countdown Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl glass-card p-6 sm:p-10 border border-volt/20 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 shadow-volt-glow">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-volt/10 border border-volt/30 text-volt text-xs font-mono font-bold">
              <span className="w-2 h-2 rounded-full bg-volt animate-ping" />
              <span>NEXT DROP RADAR: DIWALI MIDNIGHT RELEASE</span>
            </div>
            <h3 className="font-heading font-black text-2xl sm:text-3xl text-white">
              VELOCITY MONOLITH CARBON V2 (INDIA SPEC)
            </h3>
            <p className="text-xs text-zinc-400 font-mono">
              Strictly limited to 200 serialized pairs across India. Free express BlueDart dispatch.
            </p>
          </div>

          {/* Countdown Clock */}
          <div className="flex items-center gap-3">
            {[
              { label: 'HOURS', val: String(timeLeft.hours).padStart(2, '0') },
              { label: 'MINUTES', val: String(timeLeft.minutes).padStart(2, '0') },
              { label: 'SECONDS', val: String(timeLeft.seconds).padStart(2, '0') }
            ].map((unit, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="p-3 sm:p-4 rounded-2xl bg-graphite-600 border border-white/10 text-center min-w-[70px] sm:min-w-[85px]">
                  <span className="font-mono font-black text-2xl sm:text-3xl text-volt block">
                    {unit.val}
                  </span>
                  <span className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-widest">
                    {unit.label}
                  </span>
                </div>
                {i < 2 && <span className="font-mono font-bold text-xl text-zinc-600">:</span>}
              </div>
            ))}
          </div>

          <button
            onClick={() => setIsNewsletterModalOpen(true)}
            className="w-full md:w-auto px-6 py-4 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-xs uppercase tracking-wider shadow-volt-glow whitespace-nowrap shimmer-btn"
          >
            Claim 15% VIP Access Pass
          </button>
        </div>
      </section>

      {/* Featured Collection Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-mono font-bold text-volt uppercase tracking-wider">
              INDIAN FOOTWEAR LINEUP
            </span>
            <h2 className="font-heading font-black text-3xl sm:text-4xl text-white">
              ENGINEERED FOR ASPHALT & PODIUM FINISHES
            </h2>
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2">
            {['All', 'Running', 'Basketball', 'Limited Drops', 'Casual'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                  activeTab === tab
                    ? 'bg-volt text-graphite shadow-volt-glow'
                    : 'bg-graphite-300 text-zinc-400 hover:text-white border border-white/5'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* View All Button */}
        <div className="pt-6 text-center">
          <button
            onClick={() => navigateToCatalog('All')}
            className="inline-flex items-center gap-3 px-8 py-4 rounded-2xl glass-panel hover:bg-white/10 text-white font-heading font-bold text-sm tracking-wide border border-white/10 transition-all hover:scale-105"
          >
            <span>Explore Complete Indian Footwear Catalog ({PRODUCTS.length} Models)</span>
            <ArrowRight className="w-4 h-4 text-volt" />
          </button>
        </div>
      </section>

      {/* Technological Innovation Spotlight Tuned for India */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl glass-card p-8 sm:p-14 border border-white/10 relative overflow-hidden">
          <div className="absolute top-0 right-1/4 w-[400px] h-[400px] bg-volt/10 rounded-full blur-[130px] pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 space-y-6">
              <span className="text-xs font-mono font-bold text-volt uppercase tracking-wider flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-volt" />
                CLIMATE & PROPULSION SCIENCE
              </span>
              <h2 className="font-heading font-black text-3xl sm:text-5xl text-white leading-tight">
                THREE PILLARS OF <br />
                <span className="text-volt">INDIAN ROAD RESILIENCE</span>
              </h2>
              <p className="text-sm text-zinc-400 leading-relaxed">
                Traditional foams break down quickly on Indian tarmac under high summer heat and monsoon moisture. Velocity Kicks fuses aerospace carbon plates with supercritical nitrogen foam and anti-abrasion lugs.
              </p>

              <div className="space-y-4 pt-2">
                {[
                  {
                    title: 'Full-Length 3D Curved Carbon Plate',
                    desc: 'Engineered for energy return on unforgiving tarmac, stabilizing foot roll during grueling Tata Mumbai Marathon training.',
                    icon: Zap
                  },
                  {
                    title: 'Monsoon-Resistant Hydrophobic Monomesh',
                    desc: 'Repels downpour waters without absorbing weight, paired with laser-perforated airflow for 40°C Delhi heat waves.',
                    icon: CloudRain
                  },
                  {
                    title: 'Wide-Foot Indian Ergonomic Splay',
                    desc: 'Tailored specifically for broad forefoot comfort and natural toe spread, preventing midfoot cramps and blisters.',
                    icon: ShieldCheck
                  }
                ].map((feat, idx) => {
                  const IconComp = feat.icon;
                  return (
                    <div key={idx} className="flex gap-4 p-3.5 rounded-2xl glass-panel-light border border-white/5">
                      <div className="w-10 h-10 rounded-xl bg-volt/10 text-volt flex items-center justify-center flex-shrink-0">
                        <IconComp className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-heading font-bold text-sm text-white">{feat.title}</h4>
                        <p className="text-xs text-zinc-400 mt-0.5 leading-relaxed">{feat.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Interactive Image Showcase */}
            <div className="lg:col-span-6 relative flex items-center justify-center">
              <div className="relative w-full aspect-square max-w-md rounded-3xl bg-graphite-400/60 p-8 flex items-center justify-center border border-white/10 overflow-hidden">
                <img
                  src="/images/products/apex_1_volt.jpg"
                  alt="Velocity Apex-1 Carbon Indian Prototype"
                  className="w-full h-full object-contain filter drop-shadow-[0_20px_30px_rgba(0,0,0,0.9)] animate-float"
                />
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl glass-panel border border-white/10 flex items-center justify-between text-xs font-mono">
                  <span className="text-zinc-400">Model: APEX-1 CARBON</span>
                  <span className="text-volt font-bold">PAN-INDIA TESTED</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Fit Assistant Callout Banner with UK/India Sizing Focus */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-graphite-400 via-graphite-300 to-graphite-400 p-8 sm:p-12 border border-white/10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 rounded-2xl bg-volt flex items-center justify-center text-graphite shadow-volt-glow flex-shrink-0">
              <Ruler className="w-7 h-7" />
            </div>
            <div>
              <h3 className="font-heading font-black text-xl sm:text-2xl text-white">
                CONFUSED ABOUT UK VS US SIZING?
              </h3>
              <p className="text-xs text-zinc-400 mt-1 max-w-lg">
                Our Indian Fit Assistant converts your Puma, Nike, or Bata sizes directly into optimal Velocity UK/India dimensions with wide-foot allowances.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsFitModalOpen(true)}
            className="w-full md:w-auto px-7 py-4 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-xs uppercase tracking-wider shadow-volt-glow whitespace-nowrap shimmer-btn"
          >
            Launch Indian Sizing Assistant
          </button>
        </div>
      </section>

      {/* Community UGC Reviews from Indian Runners & Creators */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <span className="text-xs font-mono font-bold text-volt uppercase tracking-wider">
            INDIAN ATHLETE COMMUNITY
          </span>
          <h2 className="font-heading font-black text-3xl sm:text-4xl text-white">
            FIELD TESTED IN BENGALURU, MUMBAI & NCR
          </h2>
          <p className="text-xs text-zinc-400">
            Real runners, verified marathon finishes. Read feedback from verified buyers across India.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {UGC_REVIEWS.map((rev) => (
            <div
              key={rev.id}
              className="rounded-2xl glass-card p-5 border border-white/10 flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex gap-0.5">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-volt text-volt" />
                    ))}
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/5 text-zinc-300">
                    {rev.tag}
                  </span>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-3 border-t border-white/5 flex items-center gap-3">
                <img
                  src={rev.avatar}
                  alt={rev.author}
                  className="w-8 h-8 rounded-full object-cover border border-volt/30"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="font-heading font-bold text-xs text-white truncate">
                      {rev.author}
                    </span>
                    <ShieldCheck className="w-3.5 h-3.5 text-volt flex-shrink-0" />
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500 block truncate">
                    {rev.city || rev.product}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
