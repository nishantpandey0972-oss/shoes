import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { UGC_REVIEWS, SAMPLE_PINCODES } from '../data/products';
import { FitAssistantModal } from './FitAssistantModal';
import {
  Star,
  Heart,
  ShoppingBag,
  Sparkles,
  Ruler,
  Truck,
  RotateCcw,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Maximize2,
  Check,
  Zap,
  ArrowRight,
  Flame,
  Bell,
  Share2,
  MapPin,
  CheckCircle2,
  CreditCard,
  QrCode,
  Shield,
  Sun,
  CloudRain,
  Feather
} from 'lucide-react';

export const ProductDetailPage = () => {
  const {
    selectedProductId,
    PRODUCTS,
    formatPrice,
    addToCart,
    toggleWishlist,
    wishlist,
    sizeStandard,
    setSizeStandard,
    setIsFitModalOpen,
    setIsLightBoxOpen,
    setLightBoxImage,
    setCurrentView,
    navigateToPdp,
    showToast
  } = useShop();

  const product = PRODUCTS.find((p) => p.id === selectedProductId) || PRODUCTS[0];

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name);
  const [selectedSizeObj, setSelectedSizeObj] = useState(
    product.sizes.find((s) => s.stock > 0) || product.sizes[2]
  );
  const [quantity, setQuantity] = useState(1);
  const [activeAccordion, setActiveAccordion] = useState('description');
  const [reviewFilter, setReviewFilter] = useState('All');
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomPos, setZoomPos] = useState({ x: 0, y: 0 });

  // Pincode Delivery Checker State
  const [pincodeInput, setPincodeInput] = useState('');
  const [pincodeResult, setPincodeResult] = useState(null);
  const [pincodeLoading, setPincodeLoading] = useState(false);
  const [pincodeError, setPincodeError] = useState('');

  const isWishlisted = wishlist.includes(product.id);

  // Zoom handler
  const handleMouseMove = (e) => {
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setZoomPos({ x, y });
  };

  const handleBuyNow = () => {
    const sizeDisplay = sizeStandard === 'UK' ? selectedSizeObj.uk : sizeStandard === 'US' ? selectedSizeObj.us : selectedSizeObj.eu;
    addToCart(product, sizeDisplay, selectedColor, quantity, `${sizeStandard} / INDIA`);
    setCurrentView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNotifyMe = (sizeVal) => {
    showToast(`We will notify you via SMS/WhatsApp when UK/IND ${sizeVal} is restocked!`, 'info');
  };

  // Pincode Verification Handler
  const handleCheckPincode = (e) => {
    e.preventDefault();
    setPincodeError('');
    const cleanPin = pincodeInput.trim();
    if (!/^\d{6}$/.test(cleanPin)) {
      setPincodeError('Please enter a valid 6-digit Indian Pincode (e.g. 560001, 110001, 400001)');
      setPincodeResult(null);
      return;
    }

    setPincodeLoading(true);
    setTimeout(() => {
      setPincodeLoading(false);
      const matched = SAMPLE_PINCODES[cleanPin];
      if (matched) {
        setPincodeResult({
          pincode: cleanPin,
          city: matched.city,
          state: matched.state,
          days: matched.days,
          codAvailable: product.price <= 9999 ? true : false,
          hub: matched.hub
        });
      } else {
        // Generic valid Indian pincode fallback
        setPincodeResult({
          pincode: cleanPin,
          city: "Regional Delivery Zone",
          state: "India (20,000+ Network)",
          days: 3,
          codAvailable: product.price <= 9999 ? true : false,
          hub: "Express Air Transit Network"
        });
      }
      showToast(`Pincode ${cleanPin} serviceable by BlueDart / Delhivery!`, 'success');
    }, 400);
  };

  // Filter UGC reviews
  const filteredReviews = reviewFilter === 'All'
    ? UGC_REVIEWS
    : UGC_REVIEWS.filter((r) => r.tag === reviewFilter || r.product === product.name);

  // Related products
  const relatedProducts = PRODUCTS.filter((p) => p.id !== product.id).slice(0, 3);

  // Active size value based on standard toggle
  const getDisplaySize = (s) => {
    if (sizeStandard === 'UK') return `UK ${s.uk}`;
    if (sizeStandard === 'US') return `US ${s.us}`;
    return `EU ${s.eu}`;
  };

  // No-cost EMI 3-month calculation
  const emiPerMonth = Math.round(product.price / 3);

  return (
    <div className="pt-6 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
      
      {/* Breadcrumb row with India context */}
      <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
        <button onClick={() => setCurrentView('home')} className="hover:text-white">Home</button>
        <span>/</span>
        <button onClick={() => setCurrentView('catalog')} className="hover:text-white">Footwear</button>
        <span>/</span>
        <span className="text-zinc-500">{product.category}</span>
        <span>/</span>
        <span className="text-white font-bold truncate max-w-xs">{product.name}</span>
      </div>

      {/* Main PDP Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 xl:gap-14">
        
        {/* Left Column: Multi-Angle Gallery */}
        <div className="lg:col-span-7 space-y-4">
          {/* Main Large Image Canvas with Hover Zoom */}
          <div
            className="relative rounded-3xl glass-card p-8 sm:p-12 overflow-hidden flex items-center justify-center min-h-[380px] sm:min-h-[480px] cursor-crosshair group"
            onMouseEnter={() => setIsZoomed(true)}
            onMouseLeave={() => setIsZoomed(false)}
            onMouseMove={handleMouseMove}
          >
            {/* Background lighting flare */}
            <div className="absolute inset-0 bg-radial-gradient from-volt/10 via-transparent to-transparent opacity-60" />

            {/* Cultural Badge overlay */}
            {product.badge && (
              <span className="absolute top-6 left-6 z-20 px-3.5 py-1.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider bg-volt/15 text-volt border border-volt/30 shadow-volt-glow flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-volt" />
                {product.badge}
              </span>
            )}

            {/* Expand / Lightbox Trigger */}
            <button
              onClick={() => {
                setLightBoxImage(product.images[activeImageIndex]);
                setIsLightBoxOpen(true);
              }}
              className="absolute top-6 right-6 z-20 p-2.5 rounded-xl bg-graphite-500/80 hover:bg-graphite-400 text-zinc-300 hover:text-white border border-white/10 transition-colors"
              title="Full screen view"
            >
              <Maximize2 className="w-4 h-4" />
            </button>

            {/* Interactive Image */}
            <img
              src={product.images[activeImageIndex]}
              alt={product.name}
              className={`w-full max-h-[420px] object-contain filter drop-shadow-[0_20px_35px_rgba(0,0,0,0.8)] transition-transform duration-200 ${
                isZoomed ? 'scale-125' : 'scale-100'
              }`}
              style={
                isZoomed
                  ? { transformOrigin: `${zoomPos.x}% ${zoomPos.y}%` }
                  : undefined
              }
            />

            {/* Dynamic bottom shadow */}
            <div className="absolute bottom-6 w-3/4 h-8 bg-volt/20 rounded-full blur-xl pointer-events-none" />
          </div>

          {/* Thumbnails Strip */}
          <div className="grid grid-cols-4 gap-3">
            {product.images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImageIndex(idx)}
                className={`relative rounded-2xl glass-panel p-2.5 aspect-square flex items-center justify-center border transition-all ${
                  activeImageIndex === idx
                    ? 'border-volt ring-2 ring-volt/30 shadow-volt-glow scale-[1.02]'
                    : 'border-white/10 hover:border-white/20 opacity-70 hover:opacity-100'
                }`}
              >
                <img
                  src={img}
                  alt={`Angle ${idx + 1}`}
                  className="w-full h-full object-contain"
                />
              </button>
            ))}
          </div>

          {/* Indian Climate & High-Performance Engineering Specs */}
          <div className="p-6 rounded-2xl glass-panel border border-white/10 space-y-4">
            <h4 className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-volt" />
              Aerospace Tech Specs & Terrain Optimization
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-graphite-400 border border-white/5">
                <span className="text-zinc-500 block text-[10px]">WEIGHT</span>
                <span className="text-white font-bold">{product.specs.weight}</span>
              </div>
              <div className="p-3 rounded-xl bg-graphite-400 border border-white/5">
                <span className="text-zinc-500 block text-[10px]">DROP</span>
                <span className="text-white font-bold">{product.specs.heelDrop}</span>
              </div>
              <div className="p-3 rounded-xl bg-graphite-400 border border-white/5">
                <span className="text-zinc-500 block text-[10px]">CUSHION</span>
                <span className="text-white font-bold">{product.specs.cushioning}</span>
              </div>
              <div className="p-3 rounded-xl bg-graphite-400 border border-white/5 sm:col-span-2">
                <span className="text-zinc-500 block text-[10px]">TERRAIN TUNING</span>
                <span className="text-white font-bold">{product.specs.surface}</span>
              </div>
              <div className="p-3 rounded-xl bg-graphite-400 border border-white/5">
                <span className="text-zinc-500 block text-[10px]">FIT PROFILE</span>
                <span className="text-volt font-bold">Indian Wide Splay</span>
              </div>
            </div>

            {/* Indian Specific Feature Badges */}
            <div className="pt-2 flex flex-wrap gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-graphite-300 border border-white/10 text-xs font-mono text-zinc-300">
                <CloudRain className="w-3.5 h-3.5 text-cyan-400" />
                <span>Monsoon-Resistant Hydrophobic Sole</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-graphite-300 border border-white/10 text-xs font-mono text-zinc-300">
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>Breathable AirMesh for Indian Summers</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-graphite-300 border border-white/10 text-xs font-mono text-zinc-300">
                <Feather className="w-3.5 h-3.5 text-volt" />
                <span>Wide-Foot Comfort Fit</span>
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Product Meta, Size Matrix, Buy Actions */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Header & Rating */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-volt uppercase tracking-widest">
                {product.brand} LABS INDIA • {product.category}
              </span>
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 fill-volt text-volt" />
                <span className="font-mono font-bold text-sm text-white">{product.rating}</span>
                <span className="text-xs text-zinc-400 font-mono">({product.reviewCount} verified reviews)</span>
              </div>
            </div>

            <h1 className="font-heading font-black text-3xl sm:text-4xl text-white tracking-tight">
              {product.name}
            </h1>

            <p className="text-sm text-zinc-400 font-normal">
              {product.tagline}
            </p>
          </div>

          {/* Pricing, GST Transparency & Indian BNPL / No-Cost EMI Badges */}
          <div className="p-4 sm:p-5 rounded-2xl bg-graphite-400 border border-white/10 space-y-3">
            <div className="flex items-baseline flex-wrap gap-3">
              <span className="text-3xl sm:text-4xl font-heading font-black text-white">
                {formatPrice(product.price)}
              </span>
              {product.originalPrice && (
                <span className="text-lg font-mono text-zinc-500 line-through">
                  {formatPrice(product.originalPrice)}
                </span>
              )}
              {product.originalPrice && (
                <span className="text-xs font-mono font-bold text-volt bg-volt/10 px-2 py-0.5 rounded border border-volt/20">
                  SAVE {formatPrice(product.originalPrice - product.price)} ({Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF)
                </span>
              )}
            </div>

            {/* GST Transparency Inline Label */}
            <div className="flex items-center gap-2 text-xs font-mono text-zinc-300">
              <span className="px-2 py-0.5 rounded bg-white/10 font-bold text-[11px] text-volt border border-volt/20">
                INCL. OF ALL TAXES (GST)
              </span>
              <span className="text-zinc-500">•</span>
              <span className="text-zinc-400">MRP Inclusive of 18% GST</span>
            </div>

            {/* No-Cost EMI & BNPL Indicator */}
            <div className="p-3 rounded-xl bg-graphite-600/80 border border-white/5 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-volt" />
                  <span>No-Cost EMI from <strong>{formatPrice(emiPerMonth)}/month</strong></span>
                </span>
                <span className="text-[10px] text-volt font-bold bg-volt/10 px-2 py-0.5 rounded">
                  0% INTEREST
                </span>
              </div>
              <p className="text-[11px] font-mono text-zinc-400">
                Or 3 monthly payments of <strong>{formatPrice(emiPerMonth)}</strong> with <span className="text-zinc-200 font-bold">Bajaj Finserv, ZestMoney, Simpl & LazyPay</span>
              </p>
            </div>

            {/* COD Availability Badge */}
            <div className="flex items-center justify-between text-xs font-mono pt-1">
              {product.price <= 9999 ? (
                <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Cash on Delivery (COD) Available</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-amber-400 font-medium text-[11px]">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>Limited Drop (&gt;₹9,999): Instant UPI / Card (Extra 5% Cashback with code UPI5)</span>
                </div>
              )}
              <span className="text-zinc-500 text-[10px]">Max COD: ₹9,999</span>
            </div>
          </div>

          {/* Color Selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-zinc-400">Colorway:</span>
              <span className="text-white font-bold">{selectedColor}</span>
            </div>
            <div className="flex flex-wrap gap-2.5">
              {product.colors.map((color) => (
                <button
                  key={color.name}
                  onClick={() => setSelectedColor(color.name)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border text-xs font-mono transition-all ${
                    selectedColor === color.name
                      ? 'border-volt bg-volt/10 text-volt shadow-sm ring-1 ring-volt'
                      : 'border-white/10 text-zinc-300 hover:border-white/20 bg-graphite-400'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-white/20"
                    style={{ backgroundColor: color.hex }}
                  />
                  <span>{color.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* India-Specific Shoe Size Matrix with Conversion Toggle */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-zinc-400">Select Size:</span>
                
                {/* Size Standard Toggle: UK / INDIA (Default) | US | EU */}
                <div className="inline-flex rounded-lg bg-graphite-600 p-0.5 border border-white/10 text-[11px] font-mono">
                  {[
                    { id: 'UK', label: 'UK / INDIA (Default)' },
                    { id: 'US', label: 'US' },
                    { id: 'EU', label: 'EU' }
                  ].map((std) => (
                    <button
                      key={std.id}
                      onClick={() => setSizeStandard(std.id)}
                      className={`px-2 py-0.5 rounded-md font-bold transition-all ${
                        sizeStandard === std.id
                          ? 'bg-volt text-graphite shadow-sm'
                          : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      {std.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Fit Assistant Trigger */}
              <button
                onClick={() => setIsFitModalOpen(true)}
                className="text-xs font-mono text-volt hover:underline flex items-center gap-1.5 font-bold"
              >
                <Ruler className="w-3.5 h-3.5 text-volt" />
                <span>Fit Assistant (Find Your Indian Size)</span>
              </button>
            </div>

            {/* Selected size indicator */}
            <div className="text-[11px] font-mono text-zinc-400 flex items-center justify-between px-1">
              <span>
                Selected: <strong className="text-white">UK/IND {selectedSizeObj.uk}</strong> • US {selectedSizeObj.us} • EU {selectedSizeObj.eu}
              </span>
              <span className="text-zinc-500">Wide-Foot Friendly</span>
            </div>

            {/* Interactive Grid of Sizes */}
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {product.sizes.map((s) => {
                const isSelected = selectedSizeObj.uk === s.uk;
                const isOutOfStock = s.stock === 0;
                const label = getDisplaySize(s);

                return (
                  <button
                    key={s.uk}
                    onClick={() => {
                      if (isOutOfStock) {
                        handleNotifyMe(s.uk);
                      } else {
                        setSelectedSizeObj(s);
                      }
                    }}
                    className={`relative py-3 rounded-xl text-xs font-mono font-bold transition-all ${
                      isOutOfStock
                        ? 'bg-graphite-500/50 text-zinc-600 line-through cursor-pointer border border-white/5 hover:border-neonOrange/30'
                        : isSelected
                        ? 'bg-volt text-graphite shadow-volt-glow'
                        : 'bg-graphite-400 text-zinc-300 hover:bg-white/10 border border-white/5'
                    }`}
                    title={isOutOfStock ? `Size ${label} Out of stock - Click for restock alert` : label}
                  >
                    <span>{label}</span>
                    {isOutOfStock && (
                      <span className="block text-[8px] no-underline font-normal text-neonOrange">
                        Notify
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Interactive Indian Pincode Delivery Checker */}
          <div className="p-4 rounded-2xl bg-graphite-400/90 border border-white/10 space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-zinc-300 font-bold flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-volt" />
                <span>Delivery & COD Availability Checker</span>
              </span>
              <span className="text-[11px] text-zinc-500">20,000+ Indian Pincodes</span>
            </div>

            <form onSubmit={handleCheckPincode} className="flex gap-2">
              <input
                type="text"
                maxLength={6}
                value={pincodeInput}
                onChange={(e) => setPincodeInput(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter 6-digit Pincode (e.g. 560001)"
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-graphite-600 border border-white/10 text-white font-mono text-xs focus:border-volt focus:outline-none placeholder-zinc-500 tracking-wider"
              />
              <button
                type="submit"
                disabled={pincodeLoading}
                className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs font-bold border border-white/10 transition-colors"
              >
                {pincodeLoading ? 'Checking...' : 'Check'}
              </button>
            </form>

            {pincodeError && (
              <p className="text-[11px] font-mono text-neonOrange">{pincodeError}</p>
            )}

            {pincodeResult && (
              <div className="p-3 rounded-xl bg-graphite-600 border border-volt/20 space-y-2 animate-fade-in text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-white font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-volt" />
                    <span>Deliverable to {pincodeResult.city}, {pincodeResult.state}</span>
                  </span>
                  <span className="text-volt font-bold">Fast {pincodeResult.days} Days Express</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-zinc-400 pt-1 border-t border-white/5">
                  <div>
                    <span className="text-zinc-500">Carrier:</span> BlueDart / Delhivery Air
                  </div>
                  <div>
                    <span className="text-zinc-500">COD Status:</span>{' '}
                    <strong className={pincodeResult.codAvailable ? 'text-emerald-400' : 'text-amber-400'}>
                      {pincodeResult.codAvailable ? 'COD Available' : 'Prepaid Only'}
                    </strong>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons: Add to Bag & Buy Now */}
          <div className="space-y-3 pt-2">
            <div className="flex gap-3">
              {/* Primary Sticky Add to Cart */}
              <button
                onClick={() => {
                  const sizeVal = sizeStandard === 'UK' ? selectedSizeObj.uk : sizeStandard === 'US' ? selectedSizeObj.us : selectedSizeObj.eu;
                  addToCart(product, sizeVal, selectedColor, quantity, `${sizeStandard} / INDIA`);
                }}
                className="flex-1 py-4 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-sm uppercase tracking-wider shadow-volt-glow transition-all flex items-center justify-center gap-2 active:scale-95 shimmer-btn"
              >
                <ShoppingBag className="w-5 h-5 text-graphite" />
                <span>Add To Bag</span>
              </button>

              {/* Wishlist Button */}
              <button
                onClick={() => toggleWishlist(product.id)}
                className={`p-4 rounded-xl border transition-all ${
                  isWishlisted
                    ? 'bg-neonOrange text-white border-neonOrange shadow-orange-glow'
                    : 'bg-graphite-400 text-zinc-400 hover:text-white border-white/10'
                }`}
                title="Save to Wishlist"
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Direct Express Buy Now with UPI / COD */}
            <button
              onClick={handleBuyNow}
              className="w-full py-3.5 rounded-xl bg-white hover:bg-zinc-200 text-graphite font-heading font-black text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-2 active:scale-95"
            >
              <QrCode className="w-4 h-4 text-graphite" />
              <span>Instant Buy (UPI / GPay / PhonePe / COD)</span>
            </button>
          </div>

          {/* Indian Trust & Shipping Guarantees */}
          <div className="grid grid-cols-2 gap-3 pt-2 text-xs font-mono text-zinc-400 border-t border-white/10">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-volt" />
              <span>Fast 3–5 Day Express across India</span>
            </div>
            <div className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-volt" />
              <span>Easy 7-Day Doorstep Returns</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-volt" />
              <span>100% Authentic with NFC Chip</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-volt" />
              <span>Free Delivery on Orders &gt;₹2,499</span>
            </div>
          </div>

          {/* Accordion Tabs */}
          <div className="pt-4 border-t border-white/10 space-y-2">
            {[
              {
                id: 'description',
                title: 'Product Engineering & Design',
                content: product.description
              },
              {
                id: 'indian_adaptation',
                title: 'Monsoon Resistance & Summer Durability',
                content: "Engineered specifically to excel in extreme Indian weather: from dry 42°C summer heat in Delhi NCR to heavy monsoons in Mumbai and the Western Ghats. Constructed with hydrophobic Dyneema monomesh that prevents waterlogging, coupled with silver-ion antimicrobial insoles for odor-free breathability."
              },
              {
                id: 'shipping_rules',
                title: 'Indian Shipping & Doorstep Return Rules',
                content: "Complimentary express priority courier delivery across 20,000+ Indian pincodes on all orders over ₹2,499. Orders dispatched via BlueDart Air and Delhivery Express. Enjoy hassle-free 7-day doorstep size exchange with reverse pickup from your residence."
              },
              {
                id: 'care',
                title: 'Footwear Care Guide for Indian Roads',
                content: "Wipe down carbon plates and outsoles with a damp microfiber cloth after road runs. Avoid drying in harsh direct midday sun or using machine washing to preserve supercritical nitrogen gas foam expansion cells."
              }
            ].map((tab) => (
              <div
                key={tab.id}
                className="rounded-xl bg-graphite-400 border border-white/5 overflow-hidden"
              >
                <button
                  onClick={() =>
                    setActiveAccordion(activeAccordion === tab.id ? null : tab.id)
                  }
                  className="w-full p-4 text-left flex items-center justify-between font-heading font-bold text-sm text-white hover:text-volt transition-colors"
                >
                  <span>{tab.title}</span>
                  {activeAccordion === tab.id ? (
                    <ChevronUp className="w-4 h-4 text-volt" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-zinc-500" />
                  )}
                </button>
                {activeAccordion === tab.id && (
                  <div className="p-4 pt-0 text-xs text-zinc-400 font-normal leading-relaxed border-t border-white/5 animate-fade-in">
                    {tab.content}
                  </div>
                )}
              </div>
            ))}
          </div>

        </div>

      </div>

      {/* Social Proof & UGC Reviews Section */}
      <section className="pt-10 border-t border-white/10 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-mono font-bold text-volt uppercase tracking-wider">
              VERIFIED INDIAN ATHLETE COMMUNITY
            </span>
            <h2 className="font-heading font-black text-2xl sm:text-3xl text-white">
              FIELD TESTED IN MUMBAI, BENGALURU & DELHI NCR
            </h2>
          </div>

          {/* Filter tags */}
          <div className="flex flex-wrap gap-2">
            {['All', 'Marathon Racing', 'Court Grip', 'Streetwear', 'Durability'].map((tag) => (
              <button
                key={tag}
                onClick={() => setReviewFilter(tag)}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
                  reviewFilter === tag
                    ? 'bg-volt text-graphite shadow-volt-glow'
                    : 'bg-graphite-300 text-zinc-400 hover:text-white border border-white/5'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* UGC Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredReviews.map((rev) => (
            <div
              key={rev.id}
              className="rounded-2xl glass-card overflow-hidden flex flex-col justify-between p-5 border border-white/10 space-y-4"
            >
              <div className="space-y-3">
                {/* UGC Image */}
                <div className="w-full aspect-[4/3] rounded-xl overflow-hidden bg-graphite-300 border border-white/5">
                  <img
                    src={rev.image}
                    alt={rev.author}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>

                {/* Rating & Tag */}
                <div className="flex items-center justify-between">
                  <div className="flex gap-0.5">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-volt text-volt" />
                    ))}
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/5 text-zinc-300 border border-white/10">
                    {rev.tag}
                  </span>
                </div>

                {/* Comment */}
                <p className="text-xs text-zinc-300 leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              {/* Author, City & Verification */}
              <div className="pt-3 border-t border-white/5 flex items-center gap-3">
                <img
                  src={rev.avatar}
                  alt={rev.author}
                  className="w-8 h-8 rounded-full object-cover border border-volt/30"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="font-heading font-bold text-xs text-white truncate">
                      {rev.author}
                    </span>
                    {rev.verified && (
                      <ShieldCheck className="w-3.5 h-3.5 text-volt flex-shrink-0" />
                    )}
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500 block truncate">
                    {rev.city || rev.handle} • {rev.date}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Related Products Recommendation Row */}
      <section className="pt-8 border-t border-white/10 space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-black text-xl text-white">
            COMPLETE YOUR LINEUP
          </h3>
          <button
            onClick={() => setCurrentView('catalog')}
            className="text-xs font-mono text-volt hover:underline flex items-center gap-1 font-bold"
          >
            <span>View All Footwear</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {relatedProducts.map((rel) => (
            <div
              key={rel.id}
              onClick={() => navigateToPdp(rel.id)}
              className="p-4 rounded-2xl glass-card cursor-pointer group flex items-center gap-4"
            >
              <div className="w-20 h-20 rounded-xl bg-graphite-300 p-2 flex-shrink-0 border border-white/5">
                <img
                  src={rel.images[0]}
                  alt={rel.name}
                  className="w-full h-full object-contain filter drop-shadow group-hover:scale-105 transition-transform"
                />
              </div>
              <div className="min-w-0 flex-1">
                <span className="text-[10px] font-mono text-volt uppercase">{rel.category}</span>
                <h4 className="font-heading font-bold text-sm text-white group-hover:text-volt truncate">
                  {rel.name}
                </h4>
                <div className="flex items-center gap-2 mt-1">
                  <span className="font-mono font-bold text-sm text-zinc-300">
                    {formatPrice(rel.price)}
                  </span>
                  <span className="text-[9px] font-mono text-zinc-500">
                    (Incl. GST)
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Fit Assistant Modal */}
      <FitAssistantModal onSelectSize={(sizeVal) => {
        const found = product.sizes.find((s) => s.uk === sizeVal) || product.sizes[0];
        setSelectedSizeObj(found);
      }} />
    </div>
  );
};
