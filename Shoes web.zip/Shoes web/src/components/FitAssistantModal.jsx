import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, Check, Ruler, Sparkles, ArrowRight, RotateCcw, CloudRain, Sun } from 'lucide-react';

export const FitAssistantModal = ({ onSelectSize }) => {
  const { isFitModalOpen, setIsFitModalOpen, showToast, sizeStandard } = useShop();

  const [step, setStep] = useState(1);
  const [footWidth, setFootWidth] = useState('Wide (Standard for Indian Foot)');
  const [primaryActivity, setPrimaryActivity] = useState('Indian Road Running & Marathon');
  const [referenceBrand, setReferenceBrand] = useState('Puma India');
  const [referenceSize, setReferenceSize] = useState('8'); // UK size default

  if (!isFitModalOpen) return null;

  // Calculation logic based on UK / INDIA sizing
  let baseUkSize = parseFloat(referenceSize) || 8;
  let recommendationNote = "True to size with 0.6cm anatomical toe splay room adapted for Indian foot profiles.";

  if (footWidth.includes('Wide') || footWidth.includes('Extra Wide')) {
    recommendationNote = "Recommended for wider forefoot splay to accommodate carbon plate stiffness and prevent blisters in hot humid weather.";
  } else if (footWidth.includes('Narrow')) {
    recommendationNote = "Zero heel-slip lockdown in true-to-size with breathable micro-knit upper.";
  }

  const handleApply = () => {
    if (onSelectSize) {
      onSelectSize(baseUkSize);
    }
    showToast(`Applied Fit Assistant recommendation: UK / IND ${baseUkSize}`, 'success');
    setIsFitModalOpen(false);
    setStep(1);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-xl rounded-3xl glass-panel p-6 sm:p-8 shadow-2xl border border-white/10">
        
        {/* Close Button */}
        <button
          onClick={() => {
            setIsFitModalOpen(false);
            setStep(1);
          }}
          className="absolute top-5 right-5 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 pb-6 border-b border-white/10">
          <div className="w-10 h-10 rounded-xl bg-volt/10 border border-volt/20 flex items-center justify-center text-volt">
            <Ruler className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-heading font-black text-xl text-white">
              VELOCITY INDIA FIT ASSISTANT AI
            </h3>
            <p className="text-xs font-mono text-zinc-400">
              UK / India 3D Sizing & Climate Comfort Optimization
            </p>
          </div>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center gap-2 py-4">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`flex-1 h-1.5 rounded-full transition-all ${
                step >= s ? 'bg-volt' : 'bg-graphite-300'
              }`}
            />
          ))}
        </div>

        {/* Step 1: Foot Profile & Width */}
        {step === 1 && (
          <div className="py-4 space-y-4 animate-fade-in">
            <span className="text-xs font-mono text-volt uppercase tracking-wider">Step 1 of 3</span>
            <h4 className="font-heading font-bold text-lg text-white">
              How would you describe your foot profile?
            </h4>
            <div className="grid grid-cols-2 gap-3">
              {[
                { title: 'Wide (Standard for Indian Foot)', desc: 'Expanded forefoot splay & broad toe box' },
                { title: 'Standard D-Width', desc: 'Average balanced width & snug heel' },
                { title: 'Extra Wide Fit', desc: 'Maximum toe volume for high insteps' },
                { title: 'Slim / Narrow', desc: 'Streamlined arch & close lockdown' }
              ].map((item) => (
                <button
                  key={item.title}
                  onClick={() => setFootWidth(item.title)}
                  className={`p-4 rounded-2xl text-left border transition-all ${
                    footWidth === item.title
                      ? 'border-volt bg-volt/10 text-white ring-1 ring-volt'
                      : 'border-white/10 bg-graphite-400 text-zinc-300 hover:bg-white/5'
                  }`}
                >
                  <div className="font-heading font-bold text-sm">{item.title}</div>
                  <div className="text-[11px] font-mono text-zinc-400 mt-1">
                    {item.desc}
                  </div>
                </button>
              ))}
            </div>

            <div className="pt-4 flex justify-end">
              <button
                onClick={() => setStep(2)}
                className="px-6 py-3 rounded-xl bg-volt text-graphite font-heading font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-volt-glow"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4 text-graphite" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Indian Climate & Activity */}
        {step === 2 && (
          <div className="py-4 space-y-4 animate-fade-in">
            <span className="text-xs font-mono text-volt uppercase tracking-wider">Step 2 of 3</span>
            <h4 className="font-heading font-bold text-lg text-white">
              What is your primary climate & running environment?
            </h4>
            <div className="grid grid-cols-2 gap-3">
              {[
                { name: 'Indian Road Running & Marathon', desc: 'High-speed propulsion on asphalt & concrete' },
                { name: 'Hot Summer Daily Streetwear', desc: 'Max breathability & anti-odor in 40°C heat' },
                { name: 'Monsoon Trail & Wet Weather', desc: 'Hydrophobic protection & anti-skid grip' },
                { name: 'Hardcourt & Gym Agility', desc: 'Lateral lockdown & high-impact training' }
              ].map((act) => (
                <button
                  key={act.name}
                  onClick={() => setPrimaryActivity(act.name)}
                  className={`p-4 rounded-2xl text-left border transition-all ${
                    primaryActivity === act.name
                      ? 'border-volt bg-volt/10 text-white ring-1 ring-volt'
                      : 'border-white/10 bg-graphite-400 text-zinc-300 hover:bg-white/5'
                  }`}
                >
                  <div className="font-heading font-bold text-sm">{act.name}</div>
                  <div className="text-[11px] font-mono text-zinc-400 mt-1">{act.desc}</div>
                </button>
              ))}
            </div>

            <div className="pt-4 flex justify-between">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs font-mono text-zinc-400 hover:text-white"
              >
                Back
              </button>
              <button
                onClick={() => setStep(3)}
                className="px-6 py-3 rounded-xl bg-volt text-graphite font-heading font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-volt-glow"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4 text-graphite" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Indian Reference Brands & Result */}
        {step === 3 && (
          <div className="py-4 space-y-5 animate-fade-in">
            <span className="text-xs font-mono text-volt uppercase tracking-wider">Step 3 of 3</span>
            <h4 className="font-heading font-bold text-lg text-white">
              What size do you normally wear in popular athletic brands in India?
            </h4>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1">Brand</label>
                <select
                  value={referenceBrand}
                  onChange={(e) => setReferenceBrand(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-graphite-400 border border-white/10 text-white text-xs font-mono focus:border-volt focus:outline-none"
                >
                  <option value="Puma India">Puma India (Nitro / RS-X)</option>
                  <option value="Nike India">Nike India (Vaporfly / Pegasus)</option>
                  <option value="Adidas India">Adidas India (Adizero / Ultraboost)</option>
                  <option value="Asics India">Asics India (Novablast / Metaspeed)</option>
                  <option value="Skechers India">Skechers India (Go Run / D'Lites)</option>
                  <option value="Bata Power">Bata / Power Athletic</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1">Your UK / INDIA Size</label>
                <select
                  value={referenceSize}
                  onChange={(e) => setReferenceSize(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-graphite-400 border border-white/10 text-white text-xs font-mono focus:border-volt focus:outline-none font-bold"
                >
                  {['6', '6.5', '7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11'].map((sz) => (
                    <option key={sz} value={sz}>UK / IND {sz}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Recommendation Result Box in UK / INDIA Standard */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-volt/15 via-graphite-400 to-graphite-400 border border-volt/30 shadow-volt-glow space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-volt uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-volt" />
                  Your Recommended Indian Size
                </span>
                <span className="text-xs font-mono text-zinc-400">99.6% Fit Guarantee</span>
              </div>

              <div className="flex items-baseline gap-3">
                <span className="text-4xl font-heading font-black text-white">
                  UK / IND {baseUkSize}
                </span>
                <span className="text-xs font-mono text-zinc-400">
                  (US {baseUkSize + 1} / EU {Math.round(baseUkSize * 1.5 + 31)})
                </span>
              </div>

              <p className="text-xs text-zinc-300 font-normal">
                {recommendationNote}
              </p>

              <div className="pt-2 flex items-center gap-4 text-[11px] font-mono text-volt">
                <span>✓ Wide-Forefoot Approved</span>
                <span>✓ Monsoon Hydrophobic Fit</span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs font-mono text-zinc-400 hover:text-white flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Start Over</span>
              </button>

              <button
                onClick={handleApply}
                className="px-8 py-3.5 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-xs uppercase tracking-wider shadow-volt-glow flex items-center gap-2"
              >
                <Check className="w-4 h-4 text-graphite" />
                <span>Apply UK/IND {baseUkSize} To Product</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
