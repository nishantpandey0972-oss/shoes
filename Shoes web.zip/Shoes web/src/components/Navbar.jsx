import React, { useState, useRef, useEffect } from 'react';
import { useShop, CURRENCIES } from '../context/ShopContext';
import {
  Search,
  ShoppingBag,
  Heart,
  Menu,
  X,
  Zap,
  Globe,
  ArrowRight,
  Sparkles,
  MessageCircle,
  Truck
} from 'lucide-react';

export const Navbar = () => {
  const {
    currentView,
    setCurrentView,
    navigateToCatalog,
    navigateToPdp,
    cart,
    wishlist,
    setIsCartOpen,
    setIsWishlistOpen,
    currency,
    setCurrency,
    formatPrice,
    PRODUCTS,
    showToast
  } = useShop();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currencyMenuOpen, setCurrencyMenuOpen] = useState(false);
  const searchInputRef = useRef(null);

  // Cart total items
  const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0);

  // Search filter
  const searchResults = searchQuery.trim() === ''
    ? []
    : PRODUCTS.filter((p) =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5);

  useEffect(() => {
    if (searchOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [searchOpen]);

  const handleCategoryClick = (category) => {
    setMobileMenuOpen(false);
    navigateToCatalog(category);
  };

  const handleWhatsAppQuickChat = () => {
    showToast('Connecting to Velocity Kicks India Concierge on WhatsApp...', 'success');
    window.open('https://wa.me/919876543210?text=Hi%20Velocity%20Kicks%20India%2C%20I%20have%20a%20question%20about%20your%20drops', '_blank');
  };

  return (
    <>
      <header className="sticky top-0 z-40 w-full glass-nav transition-all duration-300">
        {/* Top announcement ticker bar with Indian market focus */}
        <div className="bg-graphite-600 border-b border-white/5 py-1.5 px-4 text-xs font-mono text-zinc-400 flex items-center justify-between overflow-hidden">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-volt animate-ping" />
            <span className="text-white font-bold">DIWALI FEST DROP LIVE:</span>
            <span>APEX-1 GOLD CARBON NOW SHIPPING ACROSS 20,000+ INDIAN PINCODES</span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-zinc-400">
            <span>USE CODE <strong className="text-volt font-bold">FESTIVE15</strong> FOR 15% OFF</span>
            <span>•</span>
            <span className="text-zinc-300 flex items-center gap-1">
              <Truck className="w-3.5 h-3.5 text-volt" />
              <span>FREE BLUEDART EXPRESS &gt;₹2,499</span>
            </span>
          </div>
        </div>

        {/* Main Navbar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          {/* Left: Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setCurrentView('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group flex items-center gap-2.5 text-left focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-volt via-volt-dark to-neonOrange flex items-center justify-center font-heading font-black text-graphite text-xl shadow-volt-glow group-hover:scale-105 transition-transform duration-300">
                V
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-heading font-black tracking-tighter text-2xl text-white group-hover:text-volt transition-colors">
                    VELOCITY
                  </span>
                  <span className="text-xs font-bold font-mono tracking-widest text-volt px-1.5 py-0.5 rounded bg-volt/10 border border-volt/20">
                    INDIA
                  </span>
                </div>
                <p className="text-[10px] tracking-widest uppercase font-mono text-zinc-400 -mt-1">
                  Engineered For Indian Roads
                </p>
              </div>
            </button>
          </div>

          {/* Center: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {[
              { label: 'All Footwear', cat: 'All' },
              { label: 'Diwali Drops', cat: 'Limited Drops', badge: 'FESTIVE' },
              { label: 'Running', cat: 'Running' },
              { label: 'Basketball', cat: 'Basketball' },
              { label: 'Monsoon Boots', cat: 'Boots' },
              { label: 'Casual', cat: 'Casual' }
            ].map((item) => (
              <button
                key={item.label}
                onClick={() => handleCategoryClick(item.cat)}
                className="relative px-3.5 py-2 text-sm font-semibold text-zinc-300 hover:text-white rounded-lg hover:bg-white/5 transition-all group"
              >
                <span>{item.label}</span>
                {item.badge && (
                  <span className="ml-1.5 text-[10px] font-mono font-bold bg-gradient-to-r from-neonOrange to-amber-500 text-white px-2 py-0.5 rounded-full shadow-orange-glow">
                    {item.badge}
                  </span>
                )}
                <span className="absolute bottom-1 left-3.5 right-3.5 h-0.5 bg-volt scale-x-0 group-hover:scale-x-100 transition-transform origin-left rounded-full" />
              </button>
            ))}
          </nav>

          {/* Right Action Icons & Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* WhatsApp Quick Concierge Button */}
            <button
              onClick={handleWhatsAppQuickChat}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 hover:text-emerald-300 border border-emerald-500/30 text-xs font-mono font-bold transition-all"
              title="Chat with Indian Concierge on WhatsApp"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>WhatsApp</span>
            </button>

            {/* Search Button */}
            <div className="relative">
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-volt transition-colors border border-white/5"
                title="Search Footwear"
              >
                <Search className="w-5 h-5" />
              </button>

              {/* Instant Search Dropdown */}
              {searchOpen && (
                <div className="absolute right-0 mt-3 w-80 sm:w-96 rounded-2xl glass-panel p-4 shadow-2xl z-50 animate-fade-in border border-white/10">
                  <div className="relative flex items-center">
                    <Search className="w-4 h-4 text-zinc-400 absolute left-3" />
                    <input
                      ref={searchInputRef}
                      type="text"
                      placeholder="Search models, carbon plates, UK sizes..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-8 py-2.5 rounded-xl bg-graphite-400 border border-white/10 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-volt font-mono"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-2.5 text-zinc-400 hover:text-white text-xs"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {/* Search Results Preview */}
                  {searchQuery.trim() !== '' && (
                    <div className="mt-3 max-h-72 overflow-y-auto space-y-2 pt-2 border-t border-white/10">
                      {searchResults.length > 0 ? (
                        searchResults.map((product) => (
                          <div
                            key={product.id}
                            onClick={() => {
                              navigateToPdp(product.id);
                              setSearchOpen(false);
                              setSearchQuery('');
                            }}
                            className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 cursor-pointer transition-colors group"
                          >
                            <img
                              src={product.images[0]}
                              alt={product.name}
                              className="w-12 h-12 rounded-lg object-contain bg-graphite-300 border border-white/5"
                            />
                            <div className="flex-1 min-w-0">
                              <h4 className="text-xs font-bold text-white group-hover:text-volt truncate">
                                {product.name}
                              </h4>
                              <p className="text-[11px] text-zinc-400 font-mono">
                                {product.category} • {formatPrice(product.price)} (Incl. GST)
                              </p>
                            </div>
                            <ArrowRight className="w-4 h-4 text-zinc-500 group-hover:text-volt opacity-0 group-hover:opacity-100 transition-opacity" />
                          </div>
                        ))
                      ) : (
                        <div className="py-6 text-center text-xs text-zinc-400">
                          No kicks found matching "{searchQuery}"
                        </div>
                      )}
                    </div>
                  )}

                  <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-zinc-400 font-mono">
                    <span>Popular: Apex-1, Diwali Gold, Titan</span>
                    <button
                      onClick={() => {
                        setSearchOpen(false);
                        navigateToCatalog('All');
                      }}
                      className="text-volt hover:underline"
                    >
                      View All
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Currency Selector (Defaults to INR ₹) */}
            <div className="relative">
              <button
                onClick={() => setCurrencyMenuOpen(!currencyMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-mono font-bold text-volt hover:text-white border border-white/10 transition-all"
              >
                <span>₹ INR</span>
              </button>

              {currencyMenuOpen && (
                <div className="absolute right-0 mt-2 w-36 rounded-xl glass-panel p-1.5 shadow-2xl z-50 border border-white/10 animate-fade-in text-xs font-mono">
                  {Object.keys(CURRENCIES).map((cur) => (
                    <button
                      key={cur}
                      onClick={() => {
                        setCurrency(cur);
                        setCurrencyMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex items-center justify-between ${
                        currency === cur
                          ? 'bg-volt/20 text-volt font-bold'
                          : 'text-zinc-300 hover:bg-white/5'
                      }`}
                    >
                      <span>{cur}</span>
                      <span className="text-zinc-500">{CURRENCIES[cur].symbol}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Wishlist Button */}
            <button
              onClick={() => setIsWishlistOpen(true)}
              className="relative p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-neonOrange transition-colors border border-white/5"
              title="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-neonOrange text-white text-[10px] font-mono font-bold flex items-center justify-center shadow-orange-glow">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Drawer Trigger */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 rounded-xl bg-volt hover:bg-volt-light text-graphite transition-all shadow-volt-glow flex items-center gap-2 group active:scale-95"
              title="View Shopping Bag"
            >
              <ShoppingBag className="w-5 h-5 text-graphite" />
              <span className="hidden sm:inline font-mono font-bold text-xs">
                {cartItemCount}
              </span>
              {cartItemCount > 0 && (
                <span className="sm:hidden absolute -top-1 -right-1 w-5 h-5 rounded-full bg-white text-graphite text-[10px] font-mono font-bold flex items-center justify-center shadow-lg">
                  {cartItemCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2.5 rounded-xl bg-white/5 text-zinc-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-graphite-500 border-b border-white/10 px-4 py-6 space-y-4 animate-fade-in">
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              {[
                { label: 'All Footwear', cat: 'All' },
                { label: 'Diwali Drops', cat: 'Limited Drops' },
                { label: 'Running', cat: 'Running' },
                { label: 'Basketball', cat: 'Basketball' },
                { label: 'Monsoon Boots', cat: 'Boots' },
                { label: 'Casual Streetwear', cat: 'Casual' }
              ].map((item) => (
                <button
                  key={item.label}
                  onClick={() => handleCategoryClick(item.cat)}
                  className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-300 text-left font-bold"
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="pt-2 border-t border-white/5 flex flex-col gap-2">
              <button
                onClick={handleWhatsAppQuickChat}
                className="w-full py-3 rounded-xl bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs flex items-center justify-center gap-2 border border-emerald-500/30"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>Chat on WhatsApp (+91 98765 43210)</span>
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
