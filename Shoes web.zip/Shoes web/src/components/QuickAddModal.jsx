import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, ShoppingBag, Check, Zap, CheckCircle2 } from 'lucide-react';

export const QuickAddModal = () => {
  const {
    isQuickAddOpen,
    setIsQuickAddOpen,
    quickAddProduct,
    addToCart,
    formatPrice,
    sizeStandard,
    setSizeStandard
  } = useShop();

  const [selectedSizeObj, setSelectedSizeObj] = useState(null);
  const [selectedColor, setSelectedColor] = useState(null);

  if (!isQuickAddOpen || !quickAddProduct) return null;

  const activeColor = selectedColor || quickAddProduct.colors[0]?.name;
  const activeSize = selectedSizeObj || quickAddProduct.sizes.find((s) => s.stock > 0) || quickAddProduct.sizes[0];

  const handleAdd = () => {
    const sizeVal = sizeStandard === 'UK' ? activeSize.uk : sizeStandard === 'US' ? activeSize.us : activeSize.eu;
    addToCart(quickAddProduct, sizeVal, activeColor, 1, `${sizeStandard} / INDIA`);
    setIsQuickAddOpen(false);
  };

  const getDisplaySize = (s) => {
    if (sizeStandard === 'UK') return `UK ${s.uk}`;
    if (sizeStandard === 'US') return `US ${s.us}`;
    return `EU ${s.eu}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl glass-panel p-6 sm:p-8 shadow-2xl border border-white/10 overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => setIsQuickAddOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Product Preview Header */}
        <div className="flex gap-4 items-center pb-6 border-b border-white/10">
          <div className="w-20 h-20 rounded-2xl bg-graphite-300 p-2 flex-shrink-0 flex items-center justify-center border border-white/5">
            <img
              src={quickAddProduct.images[0]}
              alt={quickAddProduct.name}
              className="w-full h-full object-contain filter drop-shadow-md"
            />
          </div>
          <div>
            <span className="text-xs font-mono text-volt uppercase tracking-wider">
              {quickAddProduct.category}
            </span>
            <h3 className="font-heading font-bold text-lg text-white">
              {quickAddProduct.name}
            </h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="font-heading font-bold text-base text-white">
                {formatPrice(quickAddProduct.price)}
              </span>
              <span className="text-[10px] font-mono text-zinc-400">
                (Incl. GST)
              </span>
              {quickAddProduct.originalPrice && (
                <span className="text-xs font-mono text-zinc-500 line-through">
                  {formatPrice(quickAddProduct.originalPrice)}
                </span>
              )}
            </div>
            {quickAddProduct.price <= 9999 && (
              <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 mt-1">
                <CheckCircle2 className="w-3 h-3" />
                COD Available across 20,000+ Indian Pincodes
              </span>
            )}
          </div>
        </div>

        {/* Color Variant Selection */}
        <div className="py-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-zinc-400">Colorway:</span>
            <span className="text-white font-semibold">{activeColor}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {quickAddProduct.colors.map((c) => (
              <button
                key={c.name}
                onClick={() => setSelectedColor(c.name)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-mono transition-all ${
                  activeColor === c.name
                    ? 'border-volt bg-volt/10 text-volt'
                    : 'border-white/10 text-zinc-400 hover:border-white/20'
                }`}
              >
                <span
                  className="w-3.5 h-3.5 rounded-full border border-white/20"
                  style={{ backgroundColor: c.hex }}
                />
                <span>{c.name.split('/')[0]}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Size Matrix with UK / INDIA Toggle */}
        <div className="py-3 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="text-zinc-400">Select Size:</span>
              <div className="inline-flex rounded-lg bg-graphite-600 p-0.5 border border-white/10 text-[10px]">
                {['UK', 'US', 'EU'].map((std) => (
                  <button
                    key={std}
                    onClick={() => setSizeStandard(std)}
                    className={`px-1.5 py-0.5 rounded font-bold transition-all ${
                      sizeStandard === std
                        ? 'bg-volt text-graphite shadow-sm'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    {std === 'UK' ? 'UK/IND' : std}
                  </button>
                ))}
              </div>
            </div>
            <span className="text-zinc-500">Wide Fit</span>
          </div>

          <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
            {quickAddProduct.sizes.map((s) => {
              const isSelected = activeSize.uk === s.uk;
              const isOutOfStock = s.stock === 0;
              const label = getDisplaySize(s);

              return (
                <button
                  key={s.uk}
                  disabled={isOutOfStock}
                  onClick={() => setSelectedSizeObj(s)}
                  className={`py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                    isOutOfStock
                      ? 'bg-graphite-400 text-zinc-600 line-through cursor-not-allowed border border-white/5'
                      : isSelected
                      ? 'bg-volt text-graphite shadow-volt-glow'
                      : 'bg-graphite-300 text-zinc-300 hover:bg-white/10 border border-white/5'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>

        {/* CTA Add to Bag */}
        <div className="pt-6">
          <button
            onClick={handleAdd}
            className="w-full py-4 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-sm uppercase tracking-wider shadow-volt-glow transition-all flex items-center justify-center gap-2 active:scale-95 shimmer-btn"
          >
            <ShoppingBag className="w-5 h-5 text-graphite" />
            <span>Add to Bag • {formatPrice(quickAddProduct.price)} (Incl. GST)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
