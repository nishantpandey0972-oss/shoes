import React from 'react';
import { useShop } from '../context/ShopContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const Toast = () => {
  const { toastMessage } = useShop();

  if (!toastMessage) return null;

  const { msg, type } = toastMessage;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3.5 rounded-xl bg-graphite-100 border border-white/10 text-white shadow-2xl backdrop-blur-md animate-fade-in transition-all">
      {type === 'success' && <CheckCircle2 className="w-5 h-5 text-volt flex-shrink-0" />}
      {type === 'error' && <AlertCircle className="w-5 h-5 text-neonOrange flex-shrink-0" />}
      {type === 'info' && <Info className="w-5 h-5 text-cyan-400 flex-shrink-0" />}
      <span className="text-sm font-medium pr-2">{msg}</span>
    </div>
  );
};
