import React, { useState, useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import { X, Search, Package, CheckCircle2, Truck, Plane, MapPin } from 'lucide-react';

export const OrderTrackerModal = () => {
  const { isOrderTrackerOpen, setIsOrderTrackerOpen, trackedOrder } = useShop();
  const [orderQuery, setOrderQuery] = useState('VK-IN-892415');
  const [hasSearched, setHasSearched] = useState(true);

  useEffect(() => {
    if (trackedOrder && trackedOrder.orderNumber) {
      setOrderQuery(trackedOrder.orderNumber);
      setHasSearched(true);
    }
  }, [trackedOrder, isOrderTrackerOpen]);

  if (!isOrderTrackerOpen) return null;

  const isMatchedOrder = trackedOrder && (trackedOrder.orderNumber === orderQuery.trim().toUpperCase() || trackedOrder.id === orderQuery.trim().toUpperCase());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl glass-panel p-6 sm:p-8 shadow-2xl border border-white/10 space-y-6">
        
        {/* Close Button */}
        <button
          onClick={() => setIsOrderTrackerOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-volt/10 border border-volt/20 flex items-center justify-center text-volt">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-heading font-black text-xl text-white">LIVE ORDER TRACKER</h3>
            <p className="text-xs font-mono text-zinc-400">BlueDart & Delhivery India Logistics Telemetry</p>
          </div>
        </div>

        {/* Search Input */}
        <div className="flex gap-2">
          <input
            type="text"
            value={orderQuery}
            onChange={(e) => setOrderQuery(e.target.value)}
            placeholder="Enter Order ID (e.g. VK-IN-892415)"
            className="flex-1 px-4 py-2.5 rounded-xl bg-graphite-400 border border-white/10 text-white font-mono text-xs focus:border-volt focus:outline-none uppercase"
          />
          <button
            onClick={() => setHasSearched(true)}
            className="px-4 py-2.5 rounded-xl bg-volt text-graphite font-heading font-black text-xs uppercase"
          >
            Track
          </button>
        </div>

        {/* Live Timeline Display */}
        {hasSearched && (
          <div className="p-5 rounded-2xl bg-graphite-400 border border-white/5 space-y-6 animate-fade-in">
            <div className="flex items-center justify-between text-xs font-mono pb-3 border-b border-white/5">
              <span className="text-zinc-400">Order: <strong className="text-white">{orderQuery}</strong></span>
              <span className="text-volt font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-volt animate-ping" />
                {isMatchedOrder && trackedOrder.courier ? `In Transit (${trackedOrder.courier})` : 'In Transit (BlueDart Air Cargo)'}
              </span>
            </div>

            {isMatchedOrder && trackedOrder.address && (
              <div className="p-3 rounded-xl bg-graphite-600 border border-white/5 text-[11px] font-mono text-zinc-300 flex items-center justify-between">
                <span>Destination: <strong className="text-white">{trackedOrder.address.city}, {trackedOrder.address.pincode}</strong></span>
                <span className="text-volt">{trackedOrder.address.fullName}</span>
              </div>
            )}

            <div className="space-y-4">
              {[
                { label: 'Order Confirmed & Serialized (Bengaluru Hub)', date: 'Today, 09:15 AM', done: true, icon: CheckCircle2 },
                { label: 'Tamper-Evident NFC Chip Paired & QA Pass', date: 'Today, 01:40 PM', done: true, icon: CheckCircle2 },
                { label: 'Departed Kempegowda Cargo Terminal (BLR Air)', date: 'Today, 06:30 PM', done: true, icon: Plane },
                { label: `Out for Local Courier Delivery to ${isMatchedOrder && trackedOrder.address?.city ? trackedOrder.address.city : 'Your Address'}`, date: 'Estimated Tomorrow by 11:30 AM', done: false, icon: Truck }
              ].map((step, idx) => {
                const IconComponent = step.icon;
                return (
                  <div key={idx} className="flex items-start gap-3 relative">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs ${
                      step.done ? 'bg-volt text-graphite shadow-volt-glow' : 'bg-graphite-600 text-zinc-500 border border-white/10'
                    }`}>
                      <IconComponent className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0">
                      <h5 className={`text-xs font-bold ${step.done ? 'text-white' : 'text-zinc-400'}`}>
                        {step.label}
                      </h5>
                      <span className="text-[11px] font-mono text-zinc-500">
                        {step.date}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-zinc-400">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-volt" />
                <span>Air Freight Waybill: <strong>{isMatchedOrder && trackedOrder.waybill ? trackedOrder.waybill : 'BLR-89241590'}</strong></span>
              </div>
              <span className="text-emerald-400 font-bold">On Schedule</span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
