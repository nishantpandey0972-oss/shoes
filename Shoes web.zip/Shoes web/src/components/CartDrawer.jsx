import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import {
  X,
  ShoppingBag,
  Plus,
  Minus,
  Trash2,
  ArrowRight,
  Truck,
  Sparkles,
  Check,
  ShieldCheck,
  Tag,
  QrCode,
  CheckCircle2,
  AlertCircle,
  Zap
} from 'lucide-react';

export const CartDrawer = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartSubtotalINR,
    discountAmountINR,
    discountedSubtotalINR,
    freeShippingReached,
    shippingAmountINR,
    gstInclusiveAmountINR,
    cartTotalINR,
    isCodEligible,
    codMaxLimit,
    amountNeededForFreeShippingINR,
    freeShippingProgress,
    formatPrice,
    applyPromoCode,
    discountCode,
    discountPercent,
    discountError,
    discountSuccess,
    UPSELL_ACCESSORIES,
    addToCart,
    setCurrentView
  } = useShop();

  const [inputCode, setInputCode] = useState('');

  if (!isCartOpen) return null;

  const handleApplyPromo = (e) => {
    e.preventDefault();
    if (inputCode) applyPromoCode(inputCode);
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setCurrentView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fade-in">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartOpen(false)}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer Container */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-graphite-500 border-l border-white/10 shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-volt/10 border border-volt/20 flex items-center justify-center text-volt">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div>
                <h2 className="font-heading font-black text-lg text-white">YOUR SHOPPING BAG</h2>
                <span className="text-xs font-mono text-zinc-400">
                  {cart.reduce((tot, i) => tot + i.quantity, 0)} items • Pan-India Delivery
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsCartOpen(false)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Indicator (Threshold: ₹2,499) */}
          <div className="p-4 bg-graphite-400 border-b border-white/5 space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-volt" />
                <span className="text-zinc-300">
                  {freeShippingReached ? (
                    <strong className="text-volt">FREE EXPRESS BLUEDART SHIPPING UNLOCKED!</strong>
                  ) : (
                    <>
                      Add <strong className="text-volt">{formatPrice(amountNeededForFreeShippingINR)}</strong> more for FREE shipping
                    </>
                  )}
                </span>
              </div>
              <span className="font-bold text-white">{Math.round(freeShippingProgress)}%</span>
            </div>
            
            {/* Progress Bar */}
            <div className="w-full h-1.5 rounded-full bg-graphite-600 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-volt to-volt-light transition-all duration-500 rounded-full"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="py-16 text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-white/5 flex items-center justify-center text-zinc-600">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="font-heading font-bold text-lg text-white">Your bag is empty</h3>
                <p className="text-xs text-zinc-400 max-w-xs mx-auto">
                  Looks like you haven't added any high-performance kicks to your bag yet.
                </p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="px-6 py-3 rounded-xl bg-volt text-graphite font-heading font-black text-xs uppercase tracking-wider"
                >
                  Start Exploring
                </button>
              </div>
            ) : (
              <>
                {/* Dynamic COD Verification Rule Banner */}
                <div className={`p-3 rounded-xl border text-xs font-mono flex items-start gap-2.5 ${
                  isCodEligible
                    ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                    : 'bg-amber-950/30 border-amber-500/30 text-amber-300'
                }`}>
                  {isCodEligible ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="min-w-0">
                    <span className="font-bold block">
                      {isCodEligible
                        ? 'Eligible for Cash on Delivery (COD)'
                        : `COD Limit Reached (Max ${formatPrice(codMaxLimit)})`}
                    </span>
                    <span className="text-[11px] opacity-80 block">
                      {isCodEligible
                        ? `Orders up to ${formatPrice(codMaxLimit)} are eligible for Cash on Delivery with OTP verification.`
                        : `High-value orders above ${formatPrice(codMaxLimit)} qualify for instant UPI / Net Banking with 5% extra discount (code UPI5).`}
                    </span>
                  </div>
                </div>

                {/* Items */}
                {cart.map((item) => {
                  const itemKey = `${item.id}-${item.size}-${item.color}`;
                  return (
                    <div
                      key={itemKey}
                      className="p-3.5 rounded-2xl glass-panel-light border border-white/5 flex gap-3.5 relative group"
                    >
                      {/* Thumbnail */}
                      <div className="w-20 h-20 rounded-xl bg-graphite-400 p-2 flex items-center justify-center flex-shrink-0 border border-white/5">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-contain filter drop-shadow-sm"
                        />
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0 flex flex-col justify-between">
                        <div>
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="font-heading font-bold text-sm text-white truncate">
                              {item.name}
                            </h4>
                            <button
                              onClick={() => removeFromCart(itemKey)}
                              className="text-zinc-500 hover:text-red-400 transition-colors p-1"
                              title="Remove item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <p className="text-[11px] font-mono text-zinc-400 mt-0.5">
                            Size: {item.sizeStandard || 'UK/IND'} {item.size} • {item.color}
                          </p>
                        </div>

                        {/* Quantity and Price */}
                        <div className="flex items-center justify-between pt-2">
                          <div className="flex items-center gap-2 bg-graphite-600 rounded-lg p-1 border border-white/5">
                            <button
                              onClick={() => updateCartQuantity(itemKey, -1)}
                              className="p-1 text-zinc-400 hover:text-white rounded"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-xs font-mono font-bold text-white px-1.5">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateCartQuantity(itemKey, 1)}
                              className="p-1 text-zinc-400 hover:text-white rounded"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <div className="text-right">
                            <span className="font-mono font-bold text-sm text-white block">
                              {formatPrice(item.price * item.quantity)}
                            </span>
                            <span className="text-[9px] font-mono text-zinc-500">
                              (Incl. GST)
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* Upsell / Cross-Sell Recommendations with INR pricing */}
                <div className="pt-4 border-t border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-volt" />
                      Add Indian Care Essentials
                    </span>
                    <span className="text-[10px] text-zinc-500 font-mono">Special Add-on Price</span>
                  </div>

                  <div className="space-y-2">
                    {UPSELL_ACCESSORIES.slice(0, 2).map((acc) => (
                      <div
                        key={acc.id}
                        className="flex items-center justify-between p-2.5 rounded-xl bg-graphite-400/60 border border-white/5"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img
                            src={acc.image}
                            alt={acc.name}
                            className="w-10 h-10 rounded-lg object-cover bg-graphite-300"
                          />
                          <div className="min-w-0">
                            <h5 className="text-xs font-bold text-white truncate max-w-[170px]">
                              {acc.name}
                            </h5>
                            <span className="text-[11px] font-mono text-volt font-bold">
                              {formatPrice(acc.price)}
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => addToCart(acc, 'Universal', 'Standard', 1, 'Standard')}
                          className="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-volt hover:text-graphite text-xs font-mono font-bold text-white transition-colors flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          <span>Add</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Footer & Checkout Summary */}
          {cart.length > 0 && (
            <div className="p-6 bg-graphite-400 border-t border-white/10 space-y-4">
              
              {/* Promo Code Form */}
              <form onSubmit={handleApplyPromo} className="space-y-1.5">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      placeholder="Coupon (e.g. FESTIVE15, UPI5)"
                      value={inputCode}
                      onChange={(e) => setInputCode(e.target.value)}
                      className="w-full pl-8 pr-3 py-2 text-xs rounded-xl bg-graphite-600 border border-white/10 text-white placeholder-zinc-500 focus:outline-none focus:border-volt uppercase font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-mono font-bold text-white border border-white/10 transition-colors"
                  >
                    Apply
                  </button>
                </div>
                {discountSuccess && (
                  <p className="text-[11px] font-mono text-volt">{discountSuccess}</p>
                )}
                {discountError && (
                  <p className="text-[11px] font-mono text-neonOrange">{discountError}</p>
                )}
              </form>

              {/* Price Calculations */}
              <div className="space-y-1.5 text-xs font-mono pt-2 border-t border-white/5">
                <div className="flex justify-between text-zinc-400">
                  <span>Subtotal</span>
                  <span className="text-white font-medium">{formatPrice(cartSubtotalINR)}</span>
                </div>

                {discountPercent > 0 && (
                  <div className="flex justify-between text-volt">
                    <span>Discount ({discountCode} - {discountPercent}%)</span>
                    <span>-{formatPrice(discountAmountINR)}</span>
                  </div>
                )}

                <div className="flex justify-between text-zinc-400">
                  <span>Express Delivery (India)</span>
                  <span className="text-white font-medium">
                    {shippingAmountINR === 0 ? (
                      <span className="text-volt font-bold">FREE</span>
                    ) : (
                      formatPrice(shippingAmountINR)
                    )}
                  </span>
                </div>

                {/* GST Transparency Note */}
                <div className="flex justify-between text-zinc-400 text-[11px]">
                  <span>Estimated GST (18% Included)</span>
                  <span className="text-zinc-300 font-mono">₹0 (Incl. in MRP)</span>
                </div>

                <div className="flex justify-between text-base font-heading font-black text-white pt-2 border-t border-white/10">
                  <div>
                    <span>Total Due</span>
                    <span className="block text-[10px] font-mono text-zinc-400 font-normal">
                      Incl. of all taxes (GST)
                    </span>
                  </div>
                  <span className="text-volt text-xl">{formatPrice(cartTotalINR)}</span>
                </div>
              </div>

              {/* Instant UPI Express Buttons */}
              <div className="space-y-2">
                <div className="text-[10px] font-mono text-zinc-400 text-center uppercase tracking-wider">
                  ⚡ Instant 1-Click UPI Payment
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={handleProceedToCheckout}
                    className="py-2.5 rounded-xl bg-white/5 hover:bg-white/15 text-white font-mono font-bold text-xs flex items-center justify-center gap-1 border border-white/10 transition-colors"
                  >
                    <span className="text-blue-400 font-black">G</span>
                    <span>Pay</span>
                  </button>
                  <button
                    onClick={handleProceedToCheckout}
                    className="py-2.5 rounded-xl bg-white/5 hover:bg-white/15 text-white font-mono font-bold text-xs flex items-center justify-center gap-1 border border-white/10 transition-colors"
                  >
                    <span className="text-purple-400 font-black">Phone</span>
                    <span>Pe</span>
                  </button>
                  <button
                    onClick={handleProceedToCheckout}
                    className="py-2.5 rounded-xl bg-white/5 hover:bg-white/15 text-white font-mono font-bold text-xs flex items-center justify-center gap-1 border border-white/10 transition-colors"
                  >
                    <span className="text-sky-400 font-black">Pay</span>
                    <span>tm</span>
                  </button>
                </div>
              </div>

              {/* Main Checkout Button */}
              <button
                onClick={handleProceedToCheckout}
                className="w-full py-4 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-sm uppercase tracking-wider shadow-volt-glow transition-all flex items-center justify-center gap-2 active:scale-95 shimmer-btn"
              >
                <span>Proceed to Indian Checkout</span>
                <ArrowRight className="w-5 h-5 text-graphite" />
              </button>

              <div className="flex items-center justify-center gap-1 text-[10px] font-mono text-zinc-500">
                <ShieldCheck className="w-3.5 h-3.5 text-zinc-400" />
                <span>UPI • RuPay • Net Banking • COD • 256-Bit SSL</span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
