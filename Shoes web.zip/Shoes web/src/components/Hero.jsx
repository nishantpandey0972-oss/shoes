import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { TRUST_BADGES } from '../data/products';
import {
  ArrowRight,
  Flame,
  Zap,
  ShieldCheck,
  Truck,
  RotateCcw,
  Sparkles,
  ChevronRight,
  Maximize2,
  CheckCircle2
} from 'lucide-react';

const HERO_MODELS = [
  {
    id: 'apex-1-carbon',
    title: 'APEX-1 CARBON',
    subtitle: 'Diwali Fest Prototype Edition',
    tagline: '89% Energy Return • Hydrophobic Monsoon Monomesh',
    price: 14999,
    accentColor: '#D4FF00',
    accentClass: 'text-volt border-volt/30 bg-volt/10',
    glowClass: 'shadow-volt-glow',
    image: '/images/products/apex_1_volt.jpg',
    badge: 'Diwali Fest Drop',
    specs: [
      { label: 'Weight', value: '198g' },
      { label: 'Energy Return', value: '89%' },
      { label: 'Terrain Tuning', value: 'Indian Tarmac' }
    ]
  },
  {
    id: 'titan-shift-orange',
    title: 'TITAN SHIFT PRO',
    subtitle: 'High-Top Concrete & Court Lockdown',
    tagline: 'Blaze Saffron • Multi-Directional Anti-Abrasion Outsole',
    price: 7999,
    accentColor: '#FF5500',
    accentClass: 'text-neonOrange border-neonOrange/30 bg-neonOrange/10',
    glowClass: 'shadow-orange-glow',
    image: '/images/products/titan_shift_orange.jpg',
    badge: 'Trending in Delhi NCR',
    specs: [
      { label: 'Lockdown', value: 'TPU Wing' },
      { label: 'Cushion', value: 'Zoom-Blast' },
      { label: 'Traction', value: 'Anti-Skid' }
    ]
  }
];

export const Hero = () => {
  const { navigateToPdp, navigateToCatalog, formatPrice, addToCart, PRODUCTS } = useShop();
  const [activeModelIndex, setActiveModelIndex] = useState(0);
  const activeModel = HERO_MODELS[activeModelIndex];

  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:py-20">
      {/* Background ambient lighting glows with festive saffron & volt hues */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-volt/10 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-[30rem] h-[30rem] bg-neonOrange/15 rounded-full blur-[150px] pointer-events-none" />

      {/* Background subtle grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)`,
          backgroundSize: '40px 40px'
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Hero Copy & Actions */}
          <div className="lg:col-span-6 space-y-6 lg:space-y-8 text-center lg:text-left">
            {/* Live drop status badge */}
            <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-graphite-300 border border-white/10 backdrop-blur-md">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-volt opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-volt" />
              </span>
              <span className="text-xs font-mono font-semibold text-zinc-300 uppercase tracking-wider">
                Festive Drop Series • 20,000+ Indian Pincodes Covered
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="font-heading font-black text-4xl sm:text-6xl xl:text-7xl leading-[1.05] tracking-tight text-white">
              PROPULSION TUNED FOR <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-volt via-amber-300 to-neonOrange">
                INDIAN ROADS
              </span>
            </h1>

            {/* Subheading */}
            <p className="text-base sm:text-lg text-zinc-400 font-normal max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Aerospace carbon plate engineering meets high-durability monsoon compounds.
              Velocity Kicks delivers unmatched propulsion adapted to Indian foot profiles and extreme climates.
            </p>

            {/* Key Specs Row */}
            <div className="grid grid-cols-3 gap-3 py-2 max-w-md mx-auto lg:mx-0">
              {activeModel.specs.map((spec) => (
                <div key={spec.label} className="p-3 rounded-xl bg-graphite-400 border border-white/5 text-center">
                  <div className="font-mono font-bold text-lg text-white">{spec.value}</div>
                  <div className="text-[11px] font-mono text-zinc-400 uppercase tracking-wider">{spec.label}</div>
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={() => navigateToCatalog('All')}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-volt hover:bg-volt-light text-graphite font-heading font-black text-sm tracking-wide uppercase transition-all duration-300 flex items-center justify-center gap-3 shadow-volt-glow hover:scale-[1.02] active:scale-95 shimmer-btn"
              >
                <span>Shop Festive Drops</span>
                <ArrowRight className="w-5 h-5 text-graphite" />
              </button>

              <button
                onClick={() => navigateToPdp(activeModel.id)}
                className="w-full sm:w-auto px-7 py-4 rounded-xl glass-panel-light hover:bg-white/10 text-white font-heading font-bold text-sm tracking-wide border border-white/10 transition-all duration-300 flex items-center justify-center gap-2 group"
              >
                <span>Explore {activeModel.title}</span>
                <ChevronRight className="w-4 h-4 text-zinc-400 group-hover:translate-x-1 group-hover:text-volt transition-all" />
              </button>
            </div>

            {/* Active Model Selector Buttons */}
            <div className="pt-4 flex items-center justify-center lg:justify-start gap-3">
              <span className="text-xs font-mono text-zinc-400">Featured Kicks:</span>
              {HERO_MODELS.map((model, idx) => (
                <button
                  key={model.id}
                  onClick={() => setActiveModelIndex(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
                    activeModelIndex === idx
                      ? `${model.accentClass} shadow-sm border`
                      : 'bg-graphite-300 text-zinc-400 hover:text-white'
                  }`}
                >
                  {model.title} • {formatPrice(model.price)}
                </button>
              ))}
            </div>
          </div>

          {/* Right: Interactive 3D Showcase Card */}
          <div className="lg:col-span-6 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              
              {/* Floating Glassmorphic Showcase Stage */}
              <div className="relative rounded-3xl glass-card p-6 sm:p-8 overflow-hidden border border-white/10">
                {/* Background model badge & watermark */}
                <div className="absolute top-6 left-6 z-10 flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-mono font-bold tracking-wider uppercase ${activeModel.accentClass}`}>
                    {activeModel.badge}
                  </span>
                  <span className="text-xs font-mono text-zinc-300 font-bold">
                    {formatPrice(activeModel.price)} (Incl. GST)
                  </span>
                </div>

                <div className="absolute -bottom-10 -right-10 text-[100px] sm:text-[140px] font-heading font-black text-white/[0.03] select-none pointer-events-none">
                  INDIA
                </div>

                {/* Sneaker Image with Dynamic Float Effect */}
                <div className="relative my-8 sm:my-10 flex items-center justify-center min-h-[300px] sm:min-h-[360px]">
                  <img
                    src={activeModel.image}
                    alt={activeModel.title}
                    className="w-full max-w-md sm:max-w-lg object-contain filter drop-shadow-[0_25px_35px_rgba(0,0,0,0.85)] animate-float cursor-pointer hover:scale-105 transition-transform duration-500"
                    onClick={() => navigateToPdp(activeModel.id)}
                  />
                  
                  {/* Glowing dynamic shadow beneath shoe */}
                  <div
                    className="absolute bottom-2 w-3/4 h-8 rounded-full blur-xl opacity-60"
                    style={{ backgroundColor: activeModel.accentColor }}
                  />
                </div>

                {/* Card Bottom Meta Bar */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <div>
                    <h3 className="font-heading font-bold text-lg text-white">
                      {activeModel.title}
                    </h3>
                    <p className="text-xs text-zinc-400 font-mono">
                      {activeModel.tagline}
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      const prod = PRODUCTS.find((p) => p.id === activeModel.id);
                      if (prod) addToCart(prod, 8, prod.colors[0]?.name, 1, 'UK / INDIA');
                    }}
                    className="px-4 py-2.5 rounded-xl bg-white hover:bg-volt text-graphite font-heading font-bold text-xs tracking-wider uppercase transition-colors shadow-lg active:scale-95"
                  >
                    Quick Bag (UK 8)
                  </button>
                </div>
              </div>

              {/* Floating Micro-Badges */}
              <div className="hidden sm:flex absolute -top-4 -right-4 glass-panel px-3.5 py-2 rounded-xl border border-white/10 items-center gap-2 shadow-2xl animate-bounce-slow">
                <Sparkles className="w-4 h-4 text-volt" />
                <span className="text-xs font-mono font-bold text-white">Cash on Delivery Available</span>
              </div>

              <div className="hidden sm:flex absolute -bottom-4 -left-4 glass-panel px-3.5 py-2 rounded-xl border border-white/10 items-center gap-2 shadow-2xl">
                <Flame className="w-4 h-4 text-neonOrange" />
                <span className="text-xs font-mono font-bold text-white">Free Express BlueDart Delivery</span>
              </div>
            </div>
          </div>

        </div>

        {/* Global Indian Trust Badges Banner */}
        <div className="mt-16 sm:mt-20 pt-10 border-t border-white/10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
            {TRUST_BADGES.map((badge, idx) => {
              const icons = {
                Truck: Truck,
                ShieldCheck: ShieldCheck,
                RotateCcw: RotateCcw,
                Zap: Zap
              };
              const IconComponent = icons[badge.icon] || ShieldCheck;

              return (
                <div
                  key={idx}
                  className="flex items-center gap-3.5 p-3 rounded-2xl glass-panel-light hover:border-volt/20 transition-colors"
                >
                  <div className="w-10 h-10 rounded-xl bg-volt/10 border border-volt/20 flex items-center justify-center text-volt flex-shrink-0">
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white font-heading tracking-tight">
                      {badge.title}
                    </h4>
                    <p className="text-[11px] text-zinc-400 font-mono">
                      {badge.subtitle}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
