import React from 'react';
import { useShop } from '../context/ShopContext';
import { X, ZoomIn } from 'lucide-react';

export const LightBoxModal = () => {
  const { isLightBoxOpen, setIsLightBoxOpen, lightBoxImage } = useShop();

  if (!isLightBoxOpen || !lightBoxImage) return null;

  return (
    <div
      onClick={() => setIsLightBoxOpen(false)}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-fade-in"
    >
      <button
        onClick={() => setIsLightBoxOpen(false)}
        className="absolute top-6 right-6 p-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white z-50"
      >
        <X className="w-6 h-6" />
      </button>

      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-w-5xl max-h-[90vh] flex items-center justify-center p-4"
      >
        <img
          src={lightBoxImage}
          alt="High Resolution Footwear Inspection"
          className="max-w-full max-h-[85vh] object-contain filter drop-shadow-[0_25px_50px_rgba(0,0,0,0.9)]"
        />
      </div>
    </div>
  );
};
