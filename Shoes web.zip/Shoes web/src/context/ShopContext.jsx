import React, { createContext, useContext, useState, useEffect } from 'react';
import { PRODUCTS, UPSELL_ACCESSORIES, SAMPLE_PINCODES } from '../data/products';

const ShopContext = createContext(null);

export const CURRENCIES = {
  INR: { symbol: '₹', rate: 1, label: 'INR (₹) - India' },
  USD: { symbol: '$', rate: 0.012, label: 'USD ($)' },
  EUR: { symbol: '€', rate: 0.011, label: 'EUR (€)' },
  GBP: { symbol: '£', rate: 0.0094, label: 'GBP (£)' }
};

export const FREE_SHIPPING_THRESHOLD_INR = 2499;
export const COD_MAX_LIMIT_INR = 9999;

export const ShopProvider = ({ children }) => {
  // Navigation / Views: 'home' | 'catalog' | 'pdp' | 'checkout'
  const [currentView, setCurrentView] = useState('home');
  const [selectedProductId, setSelectedProductId] = useState('apex-1-carbon');
  const [catalogCategory, setCatalogCategory] = useState('All');

  // Modals & Drawers
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isFitModalOpen, setIsFitModalOpen] = useState(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [quickAddProduct, setQuickAddProduct] = useState(null);
  const [isOrderTrackerOpen, setIsOrderTrackerOpen] = useState(false);
  const [isNewsletterModalOpen, setIsNewsletterModalOpen] = useState(false);
  const [isLightBoxOpen, setIsLightBoxOpen] = useState(false);
  const [lightBoxImage, setLightBoxImage] = useState(null);

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchActive, setIsSearchActive] = useState(false);

  // Currency - Defaults to Indian Rupee (INR)
  const [currency, setCurrency] = useState('INR');

  // Global Size standard preference: 'UK' (Standard India) | 'US' | 'EU'
  const [sizeStandard, setSizeStandard] = useState('UK');

  // Cart & Wishlist with localStorage persistence
  const [cart, setCart] = useState(() => {
    try {
      const saved = localStorage.getItem('vk_cart_inr');
      return saved ? JSON.parse(saved) : [
        {
          id: 'apex-1-carbon',
          name: 'VELOCITY APEX-1 CARBON',
          price: 14999,
          size: 8, // UK/IND 8
          sizeStandard: 'UK / INDIA',
          color: 'Volt Lime / Graphite',
          image: '/images/products/apex_1_volt.jpg',
          quantity: 1
        }
      ];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState(() => {
    try {
      const saved = localStorage.getItem('vk_wishlist');
      return saved ? JSON.parse(saved) : ['titan-shift-orange', 'stratos-glide-air'];
    } catch {
      return [];
    }
  });

  // Promo code
  const [discountCode, setDiscountCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0); // 0 to 100
  const [discountError, setDiscountError] = useState('');
  const [discountSuccess, setDiscountSuccess] = useState('');

  // Toast notifications
  const [toastMessage, setToastMessage] = useState(null);

  useEffect(() => {
    try {
      localStorage.setItem('vk_cart_inr', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('vk_wishlist', JSON.stringify(wishlist));
    } catch (e) {
      console.error(e);
    }
  }, [wishlist]);

  // Active / Placed Order for Live Telemetry Tracking
  const [trackedOrder, setTrackedOrder] = useState(() => {
    try {
      const saved = localStorage.getItem('vk_active_order');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    try {
      if (trackedOrder) {
        localStorage.setItem('vk_active_order', JSON.stringify(trackedOrder));
      }
    } catch (e) {
      console.error(e);
    }
  }, [trackedOrder]);

  // Show Toast
  const showToast = (msg, type = 'info') => {
    setToastMessage({ msg, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Indian Rupee (INR) Formatter with Indian numbering format (e.g. ₹2,999, ₹14,999)
  const formatPrice = (inrPrice) => {
    if (inrPrice === null || inrPrice === undefined || isNaN(inrPrice)) return '₹0';
    const cur = CURRENCIES[currency] || CURRENCIES.INR;
    const converted = inrPrice * cur.rate;
    if (currency === 'INR') {
      return `₹${Math.round(converted).toLocaleString('en-IN')}`;
    }
    return `${cur.symbol}${converted.toFixed(2)}`;
  };

  // Cart operations
  const addToCart = (product, size, color, quantity = 1, standard = 'UK / INDIA') => {
    const itemKey = `${product.id}-${size}-${color || 'default'}`;
    setCart((prev) => {
      const existing = prev.find((item) => `${item.id}-${item.size}-${item.color}` === itemKey);
      if (existing) {
        return prev.map((item) =>
          `${item.id}-${item.size}-${item.color}` === itemKey
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [
        ...prev,
        {
          id: product.id,
          name: product.name,
          price: product.price,
          size: size || 8,
          sizeStandard: standard,
          color: color || (product.colors?.[0]?.name ?? 'Standard'),
          image: product.images?.[0] || product.image,
          quantity
        }
      ];
    });
    showToast(`Added ${product.name} (Size ${standard} ${size || 8}) to bag!`, 'success');
    setIsCartOpen(true);
  };

  const updateCartQuantity = (itemKey, delta) => {
    setCart((prev) =>
      prev
        .map((item) => {
          const key = `${item.id}-${item.size}-${item.color}`;
          if (key === itemKey) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean)
    );
  };

  const removeFromCart = (itemKey) => {
    setCart((prev) => prev.filter((item) => `${item.id}-${item.size}-${item.color}` !== itemKey));
    showToast('Item removed from bag', 'info');
  };

  const clearCart = () => {
    setCart([]);
  };

  // Wishlist operations
  const toggleWishlist = (productId) => {
    setWishlist((prev) => {
      if (prev.includes(productId)) {
        showToast('Removed from Wishlist', 'info');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('Saved to Wishlist!', 'success');
        return [...prev, productId];
      }
    });
  };

  // Promo code validation with Indian campaigns
  const applyPromoCode = (code) => {
    const cleanCode = code.trim().toUpperCase();
    if (cleanCode === 'FESTIVE15' || cleanCode === 'DIWALI15' || cleanCode === 'VELOCITY15' || cleanCode === 'DROP15') {
      setDiscountPercent(15);
      setDiscountCode(cleanCode);
      setDiscountSuccess('15% Festive Drop Discount Applied!');
      setDiscountError('');
      showToast('Promo code applied: 15% OFF!', 'success');
    } else if (cleanCode === 'UPI5' || cleanCode === 'PREPAID5') {
      setDiscountPercent(5);
      setDiscountCode(cleanCode);
      setDiscountSuccess('5% Instant Prepaid UPI Discount Applied!');
      setDiscountError('');
      showToast('Instant 5% UPI Cashback Applied!', 'success');
    } else if (cleanCode === 'VIP25') {
      setDiscountPercent(25);
      setDiscountCode(cleanCode);
      setDiscountSuccess('25% Elite Marathoner Discount Applied!');
      setDiscountError('');
      showToast('VIP Promo applied: 25% OFF!', 'success');
    } else {
      setDiscountError('Invalid code. Try "FESTIVE15" or "VELOCITY15"');
      setDiscountSuccess('');
    }
  };

  // Cart calculations in INR
  const cartSubtotalINR = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const discountAmountINR = (cartSubtotalINR * discountPercent) / 100;
  const discountedSubtotalINR = cartSubtotalINR - discountAmountINR;
  const freeShippingReached = discountedSubtotalINR >= FREE_SHIPPING_THRESHOLD_INR;
  const shippingAmountINR = cartSubtotalINR === 0 ? 0 : freeShippingReached ? 0 : 149;
  
  // In India, prices are inclusive of 18% GST (Goods and Services Tax)
  const gstInclusiveAmountINR = Math.round((discountedSubtotalINR * 0.18) / 1.18);
  const cartTotalINR = discountedSubtotalINR + shippingAmountINR;
  const amountNeededForFreeShippingINR = Math.max(0, FREE_SHIPPING_THRESHOLD_INR - discountedSubtotalINR);
  const freeShippingProgress = Math.min(100, (discountedSubtotalINR / FREE_SHIPPING_THRESHOLD_INR) * 100);

  // Cash on Delivery (COD) eligibility rule: Available up to ₹9,999
  const isCodEligible = cartTotalINR > 0 && cartTotalINR <= COD_MAX_LIMIT_INR;

  // Navigation helpers
  const navigateToPdp = (productId) => {
    setSelectedProductId(productId);
    setCurrentView('pdp');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToCatalog = (category = 'All') => {
    setCatalogCategory(category);
    setCurrentView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <ShopContext.Provider
      value={{
        PRODUCTS,
        UPSELL_ACCESSORIES,
        SAMPLE_PINCODES,
        currentView,
        setCurrentView,
        selectedProductId,
        setSelectedProductId,
        catalogCategory,
        setCatalogCategory,
        isCartOpen,
        setIsCartOpen,
        isWishlistOpen,
        setIsWishlistOpen,
        isFitModalOpen,
        setIsFitModalOpen,
        isQuickAddOpen,
        setIsQuickAddOpen,
        quickAddProduct,
        setQuickAddProduct,
        isOrderTrackerOpen,
        setIsOrderTrackerOpen,
        isNewsletterModalOpen,
        setIsNewsletterModalOpen,
        isLightBoxOpen,
        setIsLightBoxOpen,
        lightBoxImage,
        setLightBoxImage,
        searchQuery,
        setSearchQuery,
        isSearchActive,
        setIsSearchActive,
        currency,
        setCurrency,
        sizeStandard,
        setSizeStandard,
        formatPrice,
        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        wishlist,
        toggleWishlist,
        discountCode,
        discountPercent,
        discountError,
        discountSuccess,
        applyPromoCode,
        cartSubtotalINR,
        discountAmountINR,
        discountedSubtotalINR,
        freeShippingReached,
        shippingAmountINR,
        gstInclusiveAmountINR,
        cartTotalINR,
        isCodEligible,
        codMaxLimit: COD_MAX_LIMIT_INR,
        amountNeededForFreeShippingINR,
        freeShippingProgress,
        toastMessage,
        showToast,
        navigateToPdp,
        navigateToCatalog,
        trackedOrder,
        setTrackedOrder
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
