export const PRODUCTS = [
  {
    id: "apex-1-carbon",
    name: "VELOCITY APEX-1 CARBON",
    brand: "VELOCITY",
    tagline: "Aerodynamic Carbon Propulsion & Supercritical Nitrogen-Foam",
    category: "Running",
    gender: "Unisex",
    price: 14999,
    originalPrice: 17999,
    rating: 4.96,
    reviewCount: 312,
    badge: "Diwali Fest Drop",
    badgeType: "lime", // 'lime' | 'orange' | 'white' | 'red'
    isLimitedDrop: true,
    isNew: true,
    inStock: true,
    stockLeft: 4,
    codEligible: false, // > 9999 COD rule demonstration
    indianFeatures: [
      "Breathable Hydrophobic Mesh for Indian Summers & Humid Climates",
      "Monsoon-Resistant Carbon Sole with Wet-Asphalt Grip",
      "Wide-Foot Ergonomic Splay (Adapted for Indian Foot Anatomy)"
    ],
    colors: [
      { name: "Volt Lime / Graphite", hex: "#D4FF00", secondaryHex: "#0D0D11" },
      { name: "Festive Gold / Stealth Carbon", hex: "#E5A93C", secondaryHex: "#0D0D11" },
      { name: "Cyber White / Silver", hex: "#FFFFFF", secondaryHex: "#8E8E9F" }
    ],
    sizes: [
      { uk: 6, ind: 6, us: 7, eu: 40, stock: 3 },
      { uk: 6.5, ind: 6.5, us: 7.5, eu: 40.5, stock: 4 },
      { uk: 7, ind: 7, us: 8, eu: 41, stock: 6 },
      { uk: 7.5, ind: 7.5, us: 8.5, eu: 42, stock: 2 },
      { uk: 8, ind: 8, us: 9, eu: 42.5, stock: 5 },
      { uk: 8.5, ind: 8.5, us: 9.5, eu: 43, stock: 1 },
      { uk: 9, ind: 9, us: 10, eu: 44, stock: 4 },
      { uk: 9.5, ind: 9.5, us: 10.5, eu: 44.5, stock: 0 },
      { uk: 10, ind: 10, us: 11, eu: 45, stock: 3 },
      { uk: 10.5, ind: 10.5, us: 11.5, eu: 45.5, stock: 0 },
      { uk: 11, ind: 11, us: 12, eu: 46, stock: 2 }
    ],
    images: [
      "/images/products/apex_1_volt.jpg",
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=1200&q=85"
    ],
    description: "Engineered for elite marathoners and street purists navigating Indian tarmac. The Apex-1 Carbon fuses a full-length aerospace 3D curved carbon-fiber spoon plate with supercritical dual-density nitrogen-infused VelocityFoam. Feel an explosive 89% energy return designed to withstand punishing heat and wet monsoon racing.",
    features: [
      "Full-Length 3D Aerospace Curved Carbon Plate",
      "Supercritical Dual-Density Nitrogen-Infused Aerofoam",
      "Ultralight Monomesh Upper with Hydrophobic Monsoon Barrier",
      "V-Advance High-Traction Diamond Lug Outsole (Anti-Skid on Indian Asphalt)",
      "Zero-Pressure Molded Heel Cup with Achilles Comfort Pod"
    ],
    specs: {
      weight: "198g / 6.9 oz (Men's UK 8)",
      heelDrop: "8 mm (Heel: 38mm / Forefoot: 30mm)",
      cushioning: "Max Dynamic Responsive",
      surface: "Road, Track & Indian Marathon Circuits",
      archSupport: "Neutral / High Energy"
    }
  },
  {
    id: "titan-shift-orange",
    name: "VELOCITY TITAN SHIFT",
    brand: "VELOCITY",
    tagline: "High-Top Court Lockdown & Multi-Directional Traction",
    category: "Basketball",
    gender: "Men",
    price: 7999,
    originalPrice: 9999,
    rating: 4.91,
    reviewCount: 184,
    badge: "Trending in Delhi NCR",
    badgeType: "orange",
    isLimitedDrop: false,
    isNew: true,
    inStock: true,
    stockLeft: 3,
    codEligible: true, // <= 9999
    indianFeatures: [
      "Heavy-Duty Abrasion Shield for Indian Concrete & Hard Courts",
      "Anatomical High-Collar Lateral Ankle Lockdown",
      "Ventilated Breathable Cordura Mesh Vamp for 35°C+ Sessions"
    ],
    colors: [
      { name: "Blaze Saffron / Graphite", hex: "#FF5500", secondaryHex: "#0D0D11" },
      { name: "Monolith Slate / Volt", hex: "#171720", secondaryHex: "#D4FF00" },
      { name: "Pure Arctic White", hex: "#FFFFFF", secondaryHex: "#FF5500" }
    ],
    sizes: [
      { uk: 7, ind: 7, us: 8, eu: 41, stock: 4 },
      { uk: 7.5, ind: 7.5, us: 8.5, eu: 42, stock: 5 },
      { uk: 8, ind: 8, us: 9, eu: 42.5, stock: 2 },
      { uk: 8.5, ind: 8.5, us: 9.5, eu: 43, stock: 3 },
      { uk: 9, ind: 9, us: 10, eu: 44, stock: 1 },
      { uk: 9.5, ind: 9.5, us: 10.5, eu: 44.5, stock: 0 },
      { uk: 10, ind: 10, us: 11, eu: 45, stock: 4 },
      { uk: 10.5, ind: 10.5, us: 11.5, eu: 45.5, stock: 2 },
      { uk: 11, ind: 11, us: 12, eu: 46, stock: 1 }
    ],
    images: [
      "/images/products/titan_shift_orange.jpg",
      "https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1579338559194-a162d19bf842?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1512374382149-233c42b6a83b?auto=format&fit=crop&w=1200&q=85"
    ],
    description: "Designed for instantaneous cuts, explosive lateral shifts, and punishing outdoor court battles. The Titan Shift incorporates an external carbon-weave heel harness and internal lateral outrigger cages that virtually eliminate ankle roll on Indian concrete and hardwood.",
    features: [
      "Rigid Lateral TPU Stabilizer with Carbon-Weave Wing",
      "Targeted Forefoot Zoom-Blast Kinetic Cushioning",
      "Engineered High-Tenacity Cordura Breathable Vamp",
      "Radial Herringbone Multi-Surface Outdoor & Indoor Grip",
      "Wide-Fit Forefoot Toe-Box for Maximum Splay & Agility"
    ],
    specs: {
      weight: "365g / 12.8 oz (Men's UK 8)",
      heelDrop: "10 mm",
      cushioning: "High Impact Absorption",
      surface: "Hardwood & Outdoor Concrete Courts",
      archSupport: "Structured Arch & Ankle Stabilization"
    }
  },
  {
    id: "aero-stride-hybrid",
    name: "AERO STRIDE HYBRID",
    brand: "VELOCITY",
    tagline: "Ultralight Daily Kilometer Crusher for Indian Runners",
    category: "Running",
    gender: "Unisex",
    price: 5999,
    originalPrice: 7499,
    rating: 4.88,
    reviewCount: 429,
    badge: "Bengaluru Bestseller",
    badgeType: "lime",
    isLimitedDrop: false,
    isNew: false,
    inStock: true,
    stockLeft: 12,
    codEligible: true,
    indianFeatures: [
      "Super-Ventilated Monomesh Tuned for Indian Summer Runs",
      "Anti-Bacterial Silver-Ion Insole (Odour-Free in 40°C Heat)",
      "High-Mileage Durabrasion Rubber Outsole for Rough Footpaths"
    ],
    colors: [
      { name: "Ghost White / Volt", hex: "#FFFFFF", secondaryHex: "#D4FF00" },
      { name: "Obsidian / Acid Cyan", hex: "#0D0D11", secondaryHex: "#00E5FF" },
      { name: "Fog Gray / Saffron", hex: "#E8E8EC", secondaryHex: "#FF5500" }
    ],
    sizes: [
      { uk: 5.5, ind: 5.5, us: 6.5, eu: 39, stock: 4 },
      { uk: 6, ind: 6, us: 7, eu: 40, stock: 8 },
      { uk: 6.5, ind: 6.5, us: 7.5, eu: 40.5, stock: 5 },
      { uk: 7, ind: 7, us: 8, eu: 41, stock: 9 },
      { uk: 7.5, ind: 7.5, us: 8.5, eu: 42, stock: 14 },
      { uk: 8, ind: 8, us: 9, eu: 42.5, stock: 7 },
      { uk: 8.5, ind: 8.5, us: 9.5, eu: 43, stock: 11 },
      { uk: 9, ind: 9, us: 10, eu: 44, stock: 8 },
      { uk: 9.5, ind: 9.5, us: 10.5, eu: 44.5, stock: 6 },
      { uk: 10, ind: 10, us: 11, eu: 45, stock: 5 },
      { uk: 11, ind: 11, us: 12, eu: 46, stock: 3 }
    ],
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=85",
      "/images/products/apex_1_volt.jpg",
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=1200&q=85"
    ],
    description: "The workhorse of your training rotation across Indian morning runs. Built for high mileage with an ultra-plush collar, bio-based responsive foam midsole, and moisture-wicking engineered knit that breathes continuously in tropical humidity.",
    features: [
      "Bio-Engineered VelocityPulse Foam Compound",
      "360-Degree Seamless Engineered Summer Knit Upper",
      "Flex-Groove Forefoot with Carbon Rubber Outsole",
      "Ortholite Hybrid Molded Insole with Antimicrobial Treatment"
    ],
    specs: {
      weight: "235g / 8.2 oz",
      heelDrop: "10 mm",
      cushioning: "Plush High Cushion",
      surface: "Road, Park Trails & Treadmill",
      archSupport: "Neutral"
    }
  },
  {
    id: "phantom-eclipse-matte",
    name: "PHANTOM ECLIPSE MATTE",
    brand: "VELOCITY",
    tagline: "Architectural Streetwear Monolith for Urban India",
    category: "Casual",
    gender: "Unisex",
    price: 6999,
    originalPrice: 8499,
    rating: 4.94,
    reviewCount: 97,
    badge: "Streetwear Drop",
    badgeType: "white",
    isLimitedDrop: false,
    isNew: true,
    inStock: true,
    stockLeft: 7,
    codEligible: true,
    indianFeatures: [
      "Water-Repellent Matte Coating for Dust & Monsoon Puddles",
      "Cushioned Ergonomic Memory Insole for All-Day Mall & Street Walking",
      "Wide-Fit Comfort Profile with Room for Indian Foot Splay"
    ],
    colors: [
      { name: "Triple Graphite", hex: "#0D0D11", secondaryHex: "#22222E" },
      { name: "Chalk Matte / Volt Accents", hex: "#E8E8EC", secondaryHex: "#D4FF00" },
      { name: "Smoked Ember / Saffron", hex: "#2A2A38", secondaryHex: "#FF5500" }
    ],
    sizes: [
      { uk: 6, ind: 6, us: 7, eu: 40, stock: 2 },
      { uk: 7, ind: 7, us: 8, eu: 41, stock: 5 },
      { uk: 7.5, ind: 7.5, us: 8.5, eu: 42, stock: 4 },
      { uk: 8, ind: 8, us: 9, eu: 42.5, stock: 6 },
      { uk: 8.5, ind: 8.5, us: 9.5, eu: 43, stock: 3 },
      { uk: 9, ind: 9, us: 10, eu: 44, stock: 2 },
      { uk: 10, ind: 10, us: 11, eu: 45, stock: 4 },
      { uk: 11, ind: 11, us: 12, eu: 46, stock: 0 }
    ],
    images: [
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1582588678413-dbf45f4823e9?auto=format&fit=crop&w=1200&q=85"
    ],
    description: "Born at the intersection of modern brutalist luxury and Indian underground streetwear culture. The Phantom Eclipse boasts sculpted geometric soles, stain-resistant matte nubuck overlays, and magnetic speed-lacing options tailored for Mumbai, Delhi, and Bengaluru creatives.",
    features: [
      "Geometric Sculpted EVA Architectural Midsole",
      "Matte Finish Treated Top-Grain Nubuck Overlays",
      "Concealed Reflective Underlay Badging",
      "Ergonomic Memory-Foam Footbed"
    ],
    specs: {
      weight: "310g / 10.9 oz",
      heelDrop: "6 mm",
      cushioning: "Balanced Firm",
      surface: "City Streets, Cafes & Lifestyle",
      archSupport: "Neutral Standard"
    }
  },
  {
    id: "supersonic-hyper-drive",
    name: "SUPERSONIC HYPER DRIVE V2",
    brand: "VELOCITY",
    tagline: "Track-Tuned Prototype / Sub-2 Hour Marathon Spec",
    category: "Limited Drops",
    gender: "Unisex",
    price: 18999,
    originalPrice: 22999,
    rating: 4.99,
    reviewCount: 68,
    badge: "Only 3 Pairs Left",
    badgeType: "orange",
    isLimitedDrop: true,
    isNew: true,
    inStock: true,
    stockLeft: 3,
    codEligible: false, // > 9999 prepaid only
    indianFeatures: [
      "Aerospace Serialized 3D Carbon Plate with Gold Titanium Lace Tips",
      "Featherlight 182g Construction for High-Humidity Speed",
      "Precision Laser-Cut Ventilation Siping for Sweat Evacuation"
    ],
    colors: [
      { name: "Iridescent Volt / Carbon", hex: "#D4FF00", secondaryHex: "#0D0D11" },
      { name: "Solar Saffron / Gold", hex: "#FF5500", secondaryHex: "#FFFFFF" }
    ],
    sizes: [
      { uk: 7, ind: 7, us: 8, eu: 41, stock: 1 },
      { uk: 7.5, ind: 7.5, us: 8.5, eu: 42, stock: 0 },
      { uk: 8, ind: 8, us: 9, eu: 42.5, stock: 1 },
      { uk: 8.5, ind: 8.5, us: 9.5, eu: 43, stock: 0 },
      { uk: 9, ind: 9, us: 10, eu: 44, stock: 1 },
      { uk: 10, ind: 10, us: 11, eu: 45, stock: 0 }
    ],
    images: [
      "/images/products/apex_1_volt.jpg",
      "/images/products/titan_shift_orange.jpg",
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=1200&q=85"
    ],
    description: "Strictly serialized limited release for India's elite runners. Engineered with ultra-fine Japanese Dyneema fibers woven directly into the upper, providing 15x stronger tensile strength than steel by weight while weighing a mere 182 grams.",
    features: [
      "Aerospace Serialized Carbon Composite Spine",
      "Ultra-Fine Dyneema Composite Upper Construction",
      "Dual Rocker Geometry for Seamless Propulsion",
      "Precision Laser-Cut Ventilation Siping"
    ],
    specs: {
      weight: "182g / 6.4 oz",
      heelDrop: "8 mm",
      cushioning: "Extreme Dynamic Rebound",
      surface: "Road & Elite Competition",
      archSupport: "High Performance"
    }
  },
  {
    id: "nomad-terrain-boot-v3",
    name: "NOMAD TERRAIN BOOT V3",
    brand: "VELOCITY",
    tagline: "All-Weather Monsoon & Western Ghats Trail Boot",
    category: "Boots",
    gender: "Men",
    price: 9999,
    originalPrice: 12499,
    rating: 4.93,
    reviewCount: 142,
    badge: "Monsoon Essential",
    badgeType: "lime",
    isLimitedDrop: false,
    isNew: true,
    inStock: true,
    stockLeft: 8,
    codEligible: true,
    indianFeatures: [
      "100% Monsoon-Resistant Hydrophobic Membrane",
      "Anti-Skid Vibram Megagrip Lug Outsole for Wet Mud & Mossy Rocks",
      "Reinforced Ballistic Rubber Mudguard for Tropical Downpours"
    ],
    colors: [
      { name: "Desert Olive / Khaki", hex: "#9E9EB0", secondaryHex: "#2A2A38" },
      { name: "Blackout Gore-Shield", hex: "#0D0D11", secondaryHex: "#FF5500" }
    ],
    sizes: [
      { uk: 7, ind: 7, us: 8, eu: 41, stock: 3 },
      { uk: 7.5, ind: 7.5, us: 8.5, eu: 42, stock: 4 },
      { uk: 8, ind: 8, us: 9, eu: 42.5, stock: 6 },
      { uk: 8.5, ind: 8.5, us: 9.5, eu: 43, stock: 2 },
      { uk: 9, ind: 9, us: 10, eu: 44, stock: 5 },
      { uk: 10, ind: 10, us: 11, eu: 45, stock: 3 },
      { uk: 11, ind: 11, us: 12, eu: 46, stock: 1 }
    ],
    images: [
      "https://images.unsplash.com/photo-1520639888713-7851133b1ed0?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1582588678413-dbf45f4823e9?auto=format&fit=crop&w=1200&q=85",
      "/images/products/titan_shift_orange.jpg"
    ],
    description: "Engineered for torrential monsoon rain, Western Ghats scrambles, and Himalayan treks without sacrificing modern athletic ergonomics. Equipped with waterproof GORE-TEX membrane and 5mm Vibram Megagrip lugs.",
    features: [
      "100% Waterproof & Breathable GORE-TEX Bootie",
      "Vibram Megagrip Arctic Lug Outsole with 5mm Lugs",
      "Reinforced Ballistic Rubber Rand & Mudguard",
      "Quick-Pull Speed Lace System with Anti-Slip Eyelets"
    ],
    specs: {
      weight: "440g / 15.5 oz",
      heelDrop: "11 mm",
      cushioning: "High Trail Protection",
      surface: "Western Ghats, Wet Rocks, Slush & Gravel",
      archSupport: "Reinforced Rigid Shank"
    }
  },
  {
    id: "cyber-track-3000",
    name: "CYBER TRACK 3000",
    brand: "VELOCITY",
    tagline: "High-Intensity Cross-Trainer with Lateral Cage",
    category: "Performance",
    gender: "Women",
    price: 4499,
    originalPrice: 5499,
    rating: 4.87,
    reviewCount: 219,
    badge: "Gym Trending",
    badgeType: "lime",
    isLimitedDrop: false,
    isNew: false,
    inStock: true,
    stockLeft: 10,
    codEligible: true,
    indianFeatures: [
      "Flat Wide-Base Grounding for Indian CrossFit & Heavy Squats",
      "Laser-Perforated Microfiber Tongue for Zero Pinching in Humidity",
      "Anti-Odor Silver-Weave Insole"
    ],
    colors: [
      { name: "Volt Lime / Platinum", hex: "#D4FF00", secondaryHex: "#E8E8EC" },
      { name: "Neon Orchid / Graphite", hex: "#FF007F", secondaryHex: "#0D0D11" },
      { name: "Stealth Onyx", hex: "#171720", secondaryHex: "#0D0D11" }
    ],
    sizes: [
      { uk: 3.5, ind: 3.5, us: 5.5, eu: 36, stock: 3 },
      { uk: 4, ind: 4, us: 6, eu: 36.5, stock: 4 },
      { uk: 4.5, ind: 4.5, us: 6.5, eu: 37.5, stock: 6 },
      { uk: 5, ind: 5, us: 7, eu: 38, stock: 5 },
      { uk: 5.5, ind: 5.5, us: 7.5, eu: 38.5, stock: 8 },
      { uk: 6, ind: 6, us: 8, eu: 39, stock: 4 },
      { uk: 6.5, ind: 6.5, us: 8.5, eu: 40, stock: 3 },
      { uk: 7, ind: 7, us: 9, eu: 40.5, stock: 2 }
    ],
    images: [
      "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=1200&q=85",
      "/images/products/apex_1_volt.jpg"
    ],
    description: "From heavy barbell squats to plyometric box jumps, the Cyber Track 3000 delivers wide-base grounding, dual-density footbed feedback, and abrasion-resistant toe wraps for intense training sessions.",
    features: [
      "Wide Geometric Flat Stability Heel Base",
      "Rope-Shield Textured Lateral Rubber Cladding",
      "Dual-Density Hybrid Insole with Arch Cradle",
      "Laser-Perforated Microfiber Tongue for Zero Pinch"
    ],
    specs: {
      weight: "260g / 9.1 oz",
      heelDrop: "4 mm Zero-Ramp Offset",
      cushioning: "Firm Responsive Ground Feel",
      surface: "Gym, Turf, HIIT & Cross-Training",
      archSupport: "Solid Lateral"
    }
  },
  {
    id: "stratos-glide-air",
    name: "STRATOS GLIDE AIR",
    brand: "VELOCITY",
    tagline: "Featherweight Recovery Slip-On with Aerofoam",
    category: "Casual",
    gender: "Women",
    price: 2999,
    originalPrice: 3999,
    rating: 4.89,
    reviewCount: 310,
    badge: "Top Value Pick",
    badgeType: "white",
    isLimitedDrop: false,
    isNew: false,
    inStock: true,
    stockLeft: 15,
    codEligible: true,
    indianFeatures: [
      "Adaptive 4-Way Stretch Knit for Indian Feet & High Insteps",
      "Machine-Washable Quick-Dry for Monsoon & Dust Resistance",
      "Pillow-Cloud Memory Cushion for All-Day Comfort"
    ],
    colors: [
      { name: "Cream Fog / Silver", hex: "#F4F4F6", secondaryHex: "#D5D5DC" },
      { name: "Pale Rose / Volt", hex: "#FAD2E1", secondaryHex: "#D4FF00" },
      { name: "Midnight Navy", hex: "#1A1A2E", secondaryHex: "#F4F4F6" }
    ],
    sizes: [
      { uk: 3.5, ind: 3.5, us: 5.5, eu: 36, stock: 4 },
      { uk: 4, ind: 4, us: 6, eu: 36.5, stock: 5 },
      { uk: 4.5, ind: 4.5, us: 6.5, eu: 37.5, stock: 7 },
      { uk: 5, ind: 5, us: 7, eu: 38, stock: 9 },
      { uk: 5.5, ind: 5.5, us: 7.5, eu: 38.5, stock: 12 },
      { uk: 6, ind: 6, us: 8, eu: 39, stock: 6 },
      { uk: 6.5, ind: 6.5, us: 8.5, eu: 40, stock: 4 },
      { uk: 7, ind: 7, us: 9, eu: 40.5, stock: 2 }
    ],
    images: [
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=85"
    ],
    description: "Engineered specifically for post-run recovery and all-day walking in Indian cities. Slip in effortlessly with adaptive 4-way stretch knit and experience marshmallow-soft step-in comfort.",
    features: [
      "Stretch-Fit Seamless Sock Upper with Easy Pull-Tabs",
      "Pillow-Cloud Memory Cushion Outsole",
      "Anatomical Podiatrist-Endorsed Arch Contour",
      "Machine-Washable Quick-Dry Construction"
    ],
    specs: {
      weight: "170g / 5.9 oz",
      heelDrop: "8 mm",
      cushioning: "Ultra Soft Cloud Cushion",
      surface: "All-Day Lifestyle & Recovery",
      archSupport: "Cradled Adaptive"
    }
  }
];

export const UPSELL_ACCESSORIES = [
  {
    id: "care-kit-pro",
    name: "Carbon Pro Footwear Shield & Monsoon Rain Guard Kit",
    price: 799,
    originalPrice: 1199,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=400&q=80",
    badge: "Monsoon Essential"
  },
  {
    id: "anti-crease-guards",
    name: "Aerodynamic Anti-Crease Toe Protectors (2 Pairs)",
    price: 449,
    originalPrice: 699,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=400&q=80",
    badge: "Popular"
  },
  {
    id: "kevlar-laces",
    name: "Reflective Volt & Saffron Kevlar-Weave Speed Laces",
    price: 349,
    originalPrice: 499,
    category: "Accessories",
    image: "/images/products/apex_1_volt.jpg",
    badge: "High-Visibility"
  },
  {
    id: "performance-socks",
    name: "Velocity Anti-Odor Compression Socks (3-Pack)",
    price: 599,
    originalPrice: 899,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=400&q=80",
    badge: "Best Value"
  }
];

export const UGC_REVIEWS = [
  {
    id: "ugc-1",
    author: "Kabir Sharma",
    handle: "@kabir_runs_blr",
    city: "Bengaluru, Karnataka",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80",
    image: "/images/products/apex_1_volt.jpg",
    rating: 5,
    verified: true,
    product: "VELOCITY APEX-1 CARBON",
    comment: "Clocked a personal best of 2:54 at the Tata Mumbai Marathon! The carbon plate snap on Marine Drive asphalt is unlike anything I've tried. Delivered to Bengaluru in 48 hours via BlueDart.",
    date: "2 days ago",
    tag: "Marathon Racing"
  },
  {
    id: "ugc-2",
    author: "Vikramaditya Roy",
    handle: "@vikram_hoops_mumbai",
    city: "Mumbai, Maharashtra",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80",
    image: "/images/products/titan_shift_orange.jpg",
    rating: 5,
    verified: true,
    product: "VELOCITY TITAN SHIFT",
    comment: "The ankle lockdown on Bandra concrete courts is unreal. Anti-abrasion outsoles handled both summer heat and slippery monsoon courts without missing a beat.",
    date: "5 days ago",
    tag: "Court Grip"
  },
  {
    id: "ugc-3",
    author: "Ananya Sen",
    handle: "@ananya_delhi_style",
    city: "New Delhi, Delhi NCR",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80",
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=600&q=80",
    rating: 5,
    verified: true,
    product: "PHANTOM ECLIPSE MATTE",
    comment: "Wore these all day through Connaught Place and cyber hub. Super comfortable wide-fit toe box and the matte finish doesn't pick up dust. Paid via UPI QR in seconds!",
    date: "1 week ago",
    tag: "Streetwear"
  },
  {
    id: "ugc-4",
    author: "Rohan Deshmukh",
    handle: "@rohan_pune_strides",
    city: "Pune, Maharashtra",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80",
    rating: 5,
    verified: true,
    product: "AERO STRIDE HYBRID",
    comment: "Put 400+ km on Sinhagad road and university trails. Nitrogen foam stays bouncy even in peak summer. The NFC chip verification on my phone confirmed 100% authenticity.",
    date: "2 weeks ago",
    tag: "Durability"
  }
];

export const TRUST_BADGES = [
  {
    icon: "Truck",
    title: "Fast 3–5 Day Express Delivery",
    subtitle: "Across 20,000+ Indian Pincodes (BlueDart / Delhivery)"
  },
  {
    icon: "ShieldCheck",
    title: "100% Authentic Guaranteed",
    subtitle: "Individually serialized NFC chip & ISO 9001 certified"
  },
  {
    icon: "RotateCcw",
    title: "Easy 7-Day Doorstep Returns",
    subtitle: "Hassle-free size exchange & reverse pickup"
  },
  {
    icon: "Zap",
    title: "Instant UPI & No-Cost EMI",
    subtitle: "GPay, PhonePe, Paytm, Bajaj Finserv & COD"
  }
];

// Major Indian Pincode Directory for Live Delivery Checker
export const SAMPLE_PINCODES = {
  "110001": { city: "New Delhi", state: "Delhi NCR", days: 2, cod: true, hub: "Delhi Airport Cargo Hub" },
  "110020": { city: "South Delhi", state: "Delhi NCR", days: 2, cod: true, hub: "Okhla Logistics Center" },
  "122001": { city: "Gurgaon", state: "Haryana", days: 2, cod: true, hub: "NCR Prime Hub" },
  "201301": { city: "Noida", state: "Uttar Pradesh", days: 2, cod: true, hub: "NCR East Hub" },
  "400001": { city: "Mumbai South", state: "Maharashtra", days: 2, cod: true, hub: "Mumbai Air Cargo Terminal" },
  "400050": { city: "Bandra, Mumbai", state: "Maharashtra", days: 2, cod: true, hub: "Western Mumbai Hub" },
  "411001": { city: "Pune", state: "Maharashtra", days: 3, cod: true, hub: "Pune Express Hub" },
  "560001": { city: "Bengaluru Central", state: "Karnataka", days: 1, cod: true, hub: "Velocity Flagship Hub (Indiranagar)" },
  "560034": { city: "Koramangala, Bengaluru", state: "Karnataka", days: 1, cod: true, hub: "South Bengaluru Dispatch" },
  "500001": { city: "Hyderabad", state: "Telangana", days: 2, cod: true, hub: "RGIA Cargo Hub" },
  "600001": { city: "Chennai", state: "Tamil Nadu", days: 2, cod: true, hub: "Chennai Air Hub" },
  "700001": { city: "Kolkata", state: "West Bengal", days: 3, cod: true, hub: "Kolkata Airport Cargo" },
  "380001": { city: "Ahmedabad", state: "Gujarat", days: 2, cod: true, hub: "Sardar Vallabhbhai Hub" },
  "302001": { city: "Jaipur", state: "Rajasthan", days: 3, cod: true, hub: "Jaipur Express Center" },
  "682001": { city: "Kochi", state: "Kerala", days: 3, cod: true, hub: "Kochi Marine Hub" },
  "482001": { city: "Jabalpur", state: "Madhya Pradesh", days: 4, cod: true, hub: "Central Logistics Hub" },
  "141001": { city: "Ludhiana", state: "Punjab", days: 3, cod: true, hub: "Punjab North Hub" }
};
