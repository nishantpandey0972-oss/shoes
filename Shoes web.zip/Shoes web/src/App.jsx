import React from 'react';
import { ShopProvider, useShop } from './context/ShopContext';
import { Navbar } from './components/Navbar';
import { HomeView } from './components/HomeView';
import { CatalogView } from './components/CatalogView';
import { ProductDetailPage } from './components/ProductDetailPage';
import { CheckoutView } from './components/CheckoutView';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { QuickAddModal } from './components/QuickAddModal';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { NewsletterModal } from './components/NewsletterModal';
import { LightBoxModal } from './components/LightBoxModal';
import { Toast } from './components/Toast';
import { Footer } from './components/Footer';

const MainLayout = () => {
  const { currentView } = useShop();

  return (
    <div className="min-h-screen bg-graphite flex flex-col justify-between selection:bg-volt selection:text-graphite">
      {/* Sticky Glassmorphic Navbar */}
      <Navbar />

      {/* Main Viewport */}
      <main className="flex-1">
        {currentView === 'home' && <HomeView />}
        {currentView === 'catalog' && <CatalogView />}
        {currentView === 'pdp' && <ProductDetailPage />}
        {currentView === 'checkout' && <CheckoutView />}
      </main>

      {/* Footer */}
      <Footer />

      {/* Global Modals & Drawers */}
      <CartDrawer />
      <WishlistDrawer />
      <QuickAddModal />
      <OrderTrackerModal />
      <NewsletterModal />
      <LightBoxModal />
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <ShopProvider>
      <MainLayout />
    </ShopProvider>
  );
}
