/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        graphite: {
          DEFAULT: '#0D0D11',
          50: '#2A2A38',
          100: '#22222E',
          200: '#1C1C26',
          300: '#171720',
          400: '#13131A',
          500: '#0D0D11',
          600: '#09090C',
        },
        volt: {
          light: '#E5FF4D',
          DEFAULT: '#D4FF00',
          dark: '#B5DC00',
          glow: 'rgba(212, 255, 0, 0.35)',
        },
        neonOrange: {
          DEFAULT: '#FF5500',
          hover: '#FF6F22',
          glow: 'rgba(255, 85, 0, 0.35)',
        },
        fog: {
          50: '#FAFAFB',
          100: '#F4F4F6',
          200: '#E8E8EC',
          300: '#D5D5DC',
          400: '#9E9EB0',
          500: '#6E6E82',
        }
      },
      fontFamily: {
        heading: ['"Space Grotesk"', 'sans-serif'],
        sans: ['"Inter"', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        'glass': '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
        'glass-sm': '0 4px 16px 0 rgba(0, 0, 0, 0.25)',
        'volt-glow': '0 0 25px rgba(212, 255, 0, 0.45)',
        'orange-glow': '0 0 25px rgba(255, 85, 0, 0.45)',
        'card-hover': '0 20px 40px -15px rgba(0, 0, 0, 0.5)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 4s ease-in-out infinite',
        'marquee': 'marquee 25s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px) rotate(0deg)' },
          '50%': { transform: 'translateY(-12px) rotate(1.5deg)' },
        },
        marquee: {
          '0%': { transform: 'translateX(0%)' },
          '100%': { transform: 'translateX(-50%)' },
        }
      }
    },
  },
  plugins: [],
}
